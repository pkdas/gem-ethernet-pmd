#ifndef __GEMU_RTE_H__
#define __GEMU_RTE_H__

#include "gemu_types.h"
#include "gemu_mm.h"

#define RTE_BAD_IOVA ((rte_iova_t)-1)

phys_addr_t rte_mem_virt2phy(volatile const void *virtaddr);

// dependecies for rte_mbuf_core.h
static inline rte_iova_t
rte_mbuf_iova_get(const struct rte_mbuf *m)
{
//#if RTE_IOVA_IN_MBUF
    return m->buf_iova;
//#else
//    return (rte_iova_t)m->buf_addr;
//#endif
}

// from rte_ethdev.h
struct rte_eth_thresh {
	uint8_t pthresh; /**< Ring prefetch threshold. */
	uint8_t hthresh; /**< Ring host threshold. */
	uint8_t wthresh; /**< Ring writeback threshold. */
};

struct rte_eth_rxconf {
	struct rte_eth_thresh rx_thresh; /**< Rx ring threshold registers. */
	uint16_t rx_free_thresh; /**< Drives the freeing of Rx descriptors. */
	uint8_t rx_drop_en; /**< Drop packets if no descriptors are available. */
	uint8_t rx_deferred_start; /**< Do not start queue with rte_eth_dev_start(). */
	uint16_t rx_nseg; /**< Number of descriptions in rx_seg array. */
};

struct rte_eth_txconf {
	struct rte_eth_thresh tx_thresh; /**< Tx ring threshold registers. */
	uint16_t tx_rs_thresh; /**< Drives the setting of RS bit on TXDs. */
	uint16_t tx_free_thresh; /**< Start freeing Tx buffers if there are
				      less free descriptors than this value. */

	uint8_t tx_deferred_start; /**< Do not start queue with rte_eth_dev_start(). */
	/**
	 * Per-queue Tx offloads to be set  using RTE_ETH_TX_OFFLOAD_* flags.
	 * Only offloads set on tx_queue_offload_capa or tx_offload_capa
	 * fields on rte_eth_dev_info structure are allowed to be set.
	 */
	uint64_t offloads;
};

//  from rte_mbuf_core.h

#define RTE_MBUF_F_EXTERNAL    (1ULL << 61)

#define RTE_MBUF_F_INDIRECT    (1ULL << 62)
#define RTE_MBUF_PRIV_ALIGN 8

#define RTE_MBUF_DEFAULT_DATAROOM   2048
#define RTE_MBUF_DEFAULT_BUF_SIZE   \
    (RTE_MBUF_DEFAULT_DATAROOM + RTE_PKTMBUF_HEADROOM)


#define RTE_MBUF_MAX_NB_SEGS    UINT16_MAX

#define RTE_MBUF_CLONED(mb)     ((mb)->ol_flags & RTE_MBUF_F_INDIRECT)

#define RTE_MBUF_HAS_EXTBUF(mb) ((mb)->ol_flags & RTE_MBUF_F_EXTERNAL)

#define RTE_MBUF_DIRECT(mb) \
    (!((mb)->ol_flags & (RTE_MBUF_F_INDIRECT | RTE_MBUF_F_EXTERNAL)))

#define RTE_MBUF_PORT_INVALID UINT16_MAX
#define MBUF_INVALID_PORT RTE_MBUF_PORT_INVALID

#define rte_pktmbuf_mtod_offset(m, t, o)    \
    ((t)(void *)((char *)(m)->buf_addr + (m)->data_off + (o)))

#define rte_pktmbuf_mtod(m, t) rte_pktmbuf_mtod_offset(m, t, 0)

#define rte_pktmbuf_iova_offset(m, o) \
    (rte_iova_t)(rte_mbuf_iova_get(m) + (m)->data_off + (o))

#define rte_pktmbuf_iova(m) rte_pktmbuf_iova_offset(m, 0)

//--------------------
// from rte_mbuf.h
//-------------------
#define rte_pktmbuf_pkt_len(m)   ((m)->pkt_len)
#define rte_pktmbuf_data_len(m)   ((m)->data_len)

struct rte_mbuf *rte_pktmbuf_alloc (struct rte_mempool *mp);
void rte_pktmbuf_free(struct rte_mbuf *m);

#if 0
int rte_pktmbuf_alloc_bulk (struct rte_mempool *pool, struct rte_mbuf **mbufs, unsigned count);
void rte_pktmbuf_free_bulk (struct rte_mbuf **mbufs, unsigned int count);
#endif

static ALWAYS_INLINE struct rte_mbuf *rte_mempool_pop(struct rte_mempool *mp)
{
    gemu_assert(mp->cur_count > 0);
    int i = --mp->cur_count;

    mp->bufs_popped++;
    rte_mbuf *hdr = (rte_mbuf *)(mp->bufs[i].virt_addr);
    gemu_log("Allocted current buf count %d ", mp->cur_count);
    return (hdr);
}

static ALWAYS_INLINE void rte_mempool_push(struct rte_mempool *mp, uint64_t virt_addr, uint64_t phys_addr)
{
    gemu_assert(mp->cur_count < mp->num_bufs);

    rte_mbuf *hdr = (rte_mbuf *)virt_addr;

    mp->bufs[mp->cur_count].phys_addr = phys_addr;
    mp->bufs[mp->cur_count].virt_addr = virt_addr;
    mp->bufs_pushed++;

    hdr->pkt_len = 0;

    int i = mp->cur_count;
    mp->cur_count++;
    gemu_log("Returned buf buf count %d ", mp->cur_count);
}

uint16_t rte_pktmbuf_data_room_size(struct rte_mempool *mp);

#endif // __GEMU_RTE_H__
