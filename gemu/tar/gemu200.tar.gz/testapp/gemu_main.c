#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <netinet/in.h>
#define __USE_GNU
#include <pthread.h>

//------ GEMU TEST APP types and memory management 
#include "gemu_types.h"
#include "gemu_mm.h"
#include "gemu_log.h"
#include "gemu_rte.h"

//------ GEMU GEMIO - common GEM IO functionality
#include "gemu_ext.h"
#include "gemu_gemio.h"
#include "gemu_testapp.h"

//------ GEMU TEST APP packet processing
#include "gemu_net_hdr.h"
#include "gemu_ip.h"

#define ZCU102_MPSOC_MAX_CPU  4
#define ZCU102_MPSOC_MAX_CPU_ID  (ZCU102_MPSOC_MAX_CPU-1)

int gemu_lcore_to_cpu_id(int lcore)
{
    assert(lcore <= ZCU102_MPSOC_MAX_CPU_ID);
    return (ZCU102_MPSOC_MAX_CPU_ID - lcore);
}

int gemu_device_to_lcore(int device_id)
{
    assert(device_id < 2);
    return (device_id);
}

// only devices 0 and 1 are supported 
int gemu_lcore_to_txq_id(int lcore) 
{
    assert(lcore < 2);
    return (lcore);
}

// gemu0 is the rx-poll device/port
// gemu1 is the forwarding device/port
void *gemu_poll_thread(void *arg) 
{
    gemu **devices = (gemu **)arg;

    gemu *gemu0 = devices[0];
    gemu *gemu1 = devices[1];

    int lcore0 = gemu_device_to_lcore(gemu0->config.device_id);
    gemu0->lcore = lcore0;

    int tx_q_id0 = gemu_lcore_to_txq_id(gemu0->lcore);
    int tx_q_id1 = tx_q_id0; 
    int cpu_id = gemu_lcore_to_cpu_id(gemu0->lcore);

    // only rx-q 0 is used
    gemu_rx_q *rx_q = &gemu0->rx_queues[0];
    gemu_tx_q *tx_q = &gemu0->tx_queues[tx_q_id0]; 
    gemu_tx_q *tx_q_fwd = &gemu1->tx_queues[tx_q_id1]; 

    gemu_set_affinity(cpu_id);
    printf("gemu0 id %d gemu1 id %d lcore %d cpu_id %d tx_q %d tx_fwd_q %d\n", 
            gemu0->config.device_id, gemu1->config.device_id, gemu0->lcore, cpu_id, tx_q_id0, tx_q_id1);

    // main loop for tx/rx poll
    gemu_err("\nXXXX Main poll loop begin...\n");
    while (1)
    {
        rx_q->rx_vector_size = tx_q->tx_vector_size = 0;
        tx_q_fwd->tx_vector_size = 0;

        gemu_rx_status(rx_q);

        gemu_update_rx_pi(rx_q);
        gemu_rx_complete(rx_q);
        gemu_process_rx_pkts(rx_q);

        gemu_process_tx_pkts(tx_q);
        gemu_process_tx_pkts(tx_q_fwd);

        gemu_update_tx_ci(tx_q);
        gemu_update_tx_ci(tx_q_fwd);
        gemu_tx_complete(tx_q);
        gemu_tx_complete(tx_q_fwd);

        // any error handling methods- or do in the manin thread
        // gemu_handle_error(gemu);
    }

    return NULL;
}

int main(int argc, char **argv)
{
    LONG status;
    pthread_t ti[2] = {0}; 
    
    setvbuf(stdout, NULL, _IONBF, 0);

    gemu_main *gm=malloc(sizeof(*gm));
    memset(gm, 0, sizeof(*gm));

    gemu_main_init(gm);

    rte_mempool_init();

    for (int i=0; i < 2; i++)
    {
        gemu_init(gm, i);
    }

    // launch processing threads
    gemu *devices[2];

    devices[0] = &gm->gemu_dev_list[0]; // rx-poll device
    devices[1] = &gm->gemu_dev_list[1]; // fwding tx device

    pthread_create(&ti[0], NULL, gemu_poll_thread, devices);
 
    sleep(5);

#if 1
    devices[0] = &gm->gemu_dev_list[1]; // rx-poll device
    devices[1] = &gm->gemu_dev_list[0]; // fwding tx-device
					//
    pthread_create(&ti[1], NULL, gemu_poll_thread, devices);
#endif

    pthread_join(ti[0], NULL);
    printf("1st poll thread exited\n");

#if 1
    pthread_join(ti[1], NULL);
    printf("2nd poll thread exited\n");
#endif

    close(gm->memfd);

    printf("Exiting GEMU...\n");
    return GEMU_SUCCESS;
}

