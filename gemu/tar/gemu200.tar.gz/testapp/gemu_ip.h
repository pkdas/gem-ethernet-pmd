#ifndef __GEMU_IP_H__
#define __GEMU_IP_H__

int gemu_lcore_to_txq_id(int lcore);

// each GEM device will be assigned a lcore 0..N-1  
// which will map to tx-q id
static ALWAYS_INLINE int gemu_process_arp_pkt(gemu *gemu, u8 *eth_frame, rte_mbuf *rx_pkt, u32 len)
{
    arp_hdr *arp = (arp_hdr *)(eth_frame + sizeof(ether_hdr));
    ether_hdr *eth_hdr = (ether_hdr *)eth_frame;
    int ret = 1; 

    // ARP reply is txed on the same rx interface
    if (ntohs(arp->arp_op) == ARP_OP_REQUEST)
    {
        gemu->stats.arp_req_recvd++;
        if (arp->arp_data.arp_tip == (*(u32 *)gemu->config.ip4_addr))
        {
             gemu->stats.arp_req_host_ip_recvd++;

             // send ARP response
             arp->arp_op = htons(ARP_OP_REPLY);
             memcpy(&arp->arp_data.arp_tha, gemu->config.mac_addr, 
                    sizeof(arp->arp_data.arp_tha));

             arp->arp_data.arp_sip = *(u32 *)gemu->config.ip4_addr;
             memcpy(&arp->arp_data.arp_sha, gemu->config.mac_addr, 
                    sizeof(arp->arp_data.arp_sha));

             memcpy(&eth_hdr->d_addr, &eth_hdr->s_addr, sizeof(eth_hdr->d_addr));
             memcpy(&eth_hdr->s_addr, gemu->config.mac_addr, sizeof(eth_hdr->d_addr));

             int tx_q_id = gemu_lcore_to_txq_id(gemu->lcore);
	     gemu_tx_q *tx_q = &gemu->tx_queues[tx_q_id];

	     pthread_spin_lock(&tx_q->lock);
             gemu_assert(tx_q->tx_vector_size < GEMU_TX_VECTOR_SIZE);
             tx_q->tx_vector[tx_q->tx_vector_size++] = rx_pkt; // zero copy
	     pthread_spin_unlock(&tx_q->lock);

             gemu->stats.arp_reply_sent++;
             tx_q->tx_stats.tx_added++; 
             ret = 0;
        }
    }

    return ret;
}

static ALWAYS_INLINE int gemu_process_ip_pkt(gemu *gemu, u8 *eth_frame, rte_mbuf *rx_pkt, u32 len)
{
    ip4_hdr *ip = (ip4_hdr *)(eth_frame + sizeof(ether_hdr));
    int dest_port = -1; 
    struct gemu *dest_gemu; 
    int ret = 1; 
    
    gemu_assert(ip->version_ihl == 0x45);

    if (ip->next_proto_id == IPPROTO_TCP)
    {
        gemu->stats.tcp_pkts_rxed++;
        dest_port = (gemu->config.device_id==0) ?  1 : 0; 
        gemu->stats.tcp_pkts_fwded++;
    }

    if (ip->next_proto_id == IPPROTO_UDP)
    {
        gemu->stats.udp_pkts_rxed++;
        dest_port = (gemu->config.device_id==0) ?  1 : 0; 
        gemu->stats.udp_pkts_fwded++;
    }

    if (ip->next_proto_id == IPPROTO_ICMP)
    {
        gemu->stats.icmp_pkts_rxed++;

        icmp_hdr *icmp = (icmp_hdr *)(ip+1); 

        if (icmp->icmp_type == IP_ICMP_ECHO_REQUEST)
        {
            if (ip->dst_addr == (*(u32 *)gemu->config.ip4_addr))
            {
                gemu->stats.icmp_echo_requests++;
                icmp->icmp_type = IP_ICMP_ECHO_REPLY;
                icmp->icmp_cksum = 0; // HW CRC offload

                dest_port = gemu->config.device_id;

                gemu->stats.icmp_echo_replies++;

                // swap dst and src mac 
                // swap dst and src ip
                u32 dst_ip_addr = ip->dst_addr;
                ip->dst_addr = ip->src_addr;
                ip->src_addr = dst_ip_addr; 
                ip->hdr_checksum = 0; // HW CRC offload
            } else
            {
                dest_port = (gemu->config.device_id==0) ?  1 : 0; 
                gemu->stats.icmp_echo_req_fwded++;
            }
        } else if (icmp->icmp_type == IP_ICMP_ECHO_REPLY)
        {
            dest_port = (gemu->config.device_id==0) ?  1 : 0;
            gemu->stats.icmp_echo_reply_fwded++;

        } else
        {
            printf("Unexpected ICMP packet type 0x%0x", icmp->icmp_type);
        }
    }

    if (dest_port == -1)
    {
        gemu->stats.rx_pkts_tossed++;
        return ret;
    }

    gemu_assert((dest_port == 0) || (dest_port == 1));
    gemu_main *gm = gemu->gm;

    dest_gemu = &gm->gemu_dev_list[dest_port]; 

    ether_hdr *eth_hdr = (ether_hdr *)eth_frame;

    if (dest_port != gemu->config.device_id)
    {
         // forwarding 
         memcpy(&eth_hdr->d_addr, dest_gemu->config.next_hop_mac, sizeof(eth_hdr->d_addr)); 
         gemu->stats.ip_pkts_fwded++;
    } else
    {
         memcpy(&eth_hdr->d_addr, &eth_hdr->s_addr, sizeof(eth_hdr->d_addr));
    }
    memcpy(&eth_hdr->s_addr, dest_gemu->config.mac_addr, sizeof(eth_hdr->d_addr));

    int tx_q_id = gemu_lcore_to_txq_id(gemu->lcore);
    gemu_tx_q *tx_q = &dest_gemu->tx_queues[tx_q_id];
    ip->packet_id = tx_q->tx_pkt_id++;

    pthread_spin_lock(&tx_q->lock);
    gemu_assert(tx_q->tx_vector_size < GEMU_TX_VECTOR_SIZE);
    tx_q->tx_vector[tx_q->tx_vector_size++] = rx_pkt; // zero copy
    pthread_spin_unlock(&tx_q->lock);

    ret = 0;

    tx_q->tx_stats.tx_added++; 
    if (gemu != dest_gemu)
    {
        tx_q->tx_stats.fwded_tx_added++;
    }
    return ret; 
}

static ALWAYS_INLINE void gemu_process_rx_pkt(gemu *gemu, rte_mbuf *rx_pkt)
{
    u32 len = rx_pkt->pkt_len; 
    u8 *eth_frame = rte_pktmbuf_mtod(rx_pkt, u8 *);
    ether_hdr *eth_hdr = (ether_hdr *)eth_frame;
    assert(rx_pkt->pool);
    assert(rx_pkt->pool->rx_q);
    gemu_rx_q *rx_q = rx_pkt->pool->rx_q;

    if (eth_hdr->ether_type == 0x0608)
    {
        gemu->stats.rx_arp_pkts++;
        if (gemu_process_arp_pkt(gemu, eth_frame, rx_pkt, len) != 0)
        {
            gemu->stats.rx_bufs_freed++;
            rte_pktmbuf_free(rx_pkt); 
            rx_q->rx_stats.bufs_pushed_tossed_arp_pkts++;
        }
        return;
    }

    // 0x0800 big-endian
    if (eth_hdr->ether_type == 0x0008)
    {
        gemu->stats.rx_ip_pkts++;
        if (gemu_process_ip_pkt(gemu, eth_frame, rx_pkt, len) != 0)
        {
            gemu->stats.rx_bufs_freed++;
	    rte_pktmbuf_free(rx_pkt);
            rx_q->rx_stats.bufs_pushed_tossed_ip_pkts++;
        }
        return;
    } 
    gemu->stats.rx_nonip_pkts++;
    gemu->stats.rx_bufs_freed++;

    rte_pktmbuf_free(rx_pkt);
    rx_q->rx_stats.bufs_pushed_tossed_non_ip_pkts++;
}

static ALWAYS_INLINE void gemu_process_rx_pkts(gemu_rx_q *rx_q) 
{
    gemu *gemu = rx_q->gemu;

    for (int i=0; i < rx_q->rx_vector_size; i++)
    {
        rte_mbuf *rx_pkt = rx_q->rx_vector[i];
        gemu_process_rx_pkt(gemu, rx_pkt);
    }
}

static ALWAYS_INLINE void gemu_process_tx_pkts(gemu_tx_q *tx_q) 
{
    gemu *gemu = tx_q->gemu;

    gemu_tx_vector(tx_q);

    return;
}


#endif // __GEMU_IP_H__
