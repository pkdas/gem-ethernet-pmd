#include <stdio.h>
#include <string.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/mman.h>
#include <errno.h>
#include <fcntl.h>
#include <stdint.h>
#include <assert.h>
#include <stdbool.h>
#include "gemu_mm.h"
#include "gemu_log.h"
#include "gemu_rte.h"
//#include "gemu_testapp.h"

struct rte_mbuf *rte_pktmbuf_alloc (struct rte_mempool *mp)
{
    return (rte_mempool_pop(mp));
}

int rte_pktmbuf_alloc_bulk(struct rte_mempool *pool, struct rte_mbuf **mbufs, unsigned count)
{
}

void rte_pktmbuf_free(struct rte_mbuf *m)
{
    assert(m->pool);
    rte_mempool_push(m->pool, (uint64_t)m, (m->buf_iova-sizeof(struct rte_mbuf)));
}

void rte_pktmbuf_free_bulk(struct rte_mbuf **mbufs, unsigned int count)
{
}

uint16_t rte_pktmbuf_data_room_size(struct rte_mempool *mp)
{
    return 0;
}
