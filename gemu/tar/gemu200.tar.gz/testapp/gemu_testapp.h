#ifndef __GEMU_TESTAPP_H__
#define __GEMU_TESTAPP_H__

#include "gemu_types.h"
#include "gemu_mm.h"
#include "gemu.h"

#if 0
static void gemu_dev_configure(gemu *gemu, int device_id, UINTPTR base_virt_addr)
{
    gemu_config *config;

    if (!gemu->config.base_addr)
    {
        gemu_assert(base_virt_addr);
        config = gemu_lookup_config(device_id);
        memcpy(&gemu->config, config, sizeof(gemu->config));
        gemu->config.base_addr = base_virt_addr;
    }

    // gemu_read_desc(gemu);
    // exit(0);

    // start from clean state
    // gemu_hw_reset(gemu); PK FIXME

    gemu_disable(gemu);

    for (int i=0; i < gemu->num_rx_queues; i++)
    {
        gemu_rx_q_setup(gemu, i);
    }

    for (int i=0; i < gemu->num_tx_queues; i++)
    {
        gemu_tx_q_setup(gemu, i);
    }

    gemu_configure_queue_ptrs(gemu);
}

// configure per port/device rx_bd_count, tx_bd_count
// per rx-q, tx-q todo FIXME PK
// allocate rx_bd descs memory and rx-bufs memory, initialize rx_q
static LONG gemu_rx_q_setup(gemu *gemu, int rx_q_id)
{
    gemu_config *config = &gemu->config;

    gemu_assert (config->base_addr);

    assert(rx_q_id <GEM_MAX_RX_QUEUES);

    gemu_rx_q *rx_q = &gemu->rx_queues[rx_q_id];

    assert(rx_q->rx_q_id == rx_q_id);

    gemu_assert (!rx_q->rx_bd_mem);

    rx_q->rx_bd_count = gemu->config.rx_bd_count;
    rx_q->rx_bd_memsize = rx_q->rx_bd_count * sizeof (gemu_bd);

    gemu_desc *rx_bd_mem;
    rx_bd_mem = (gemu_desc *)rte_mempool_alloc_bdmem(rx_q->rx_bd_memsize);
    assert(rx_bd_mem);

    rx_q->phys_rx_bd_mem = rte_mem_virt2phy(rx_bd_mem);
    assert(rx_q->phys_rx_bd_mem != RTE_BAD_IOVA);

    rx_q->rx_bd_mem = rx_bd_mem;
    gemu_log("GEM %s tx_q %d\n", gemu->config.name, rx_q_id);
    gemu_log("BD mem allocated, rx_bd_count %d rx_bd_memsz %d, rx_bd_mem %p phys_rx_bd_mem %p\n",
        rx_q->rx_bd_count, rx_q->rx_bd_memsize,  rx_q->rx_bd_mem, (void *)rx_q->phys_rx_bd_mem);

    rx_q->rx_pi = 0;
    rx_q->rx_ci = 0;

    // allocate buffers
    struct rte_mempool *mp = &rx_q->mp;
    rte_mempool_alloc_bufmem(gemu, mp, rx_q->rx_bd_count);

    gemu_assert(mp->bufmem_start);
    gemu_assert(mp->bufmem_end);

    gemu_init_rx_bds(gemu, rx_q);

    return GEMU_SUCCESS;
}

static ALWAYS_INLINE void gemu_init(gemu_main *gm, int gem_id)
{
    assert(gem_id < GEM_MAX_DEVICES);

    volatile void *gem_mapped_base, *gem_base_addr;
    off_t gem_dev_base = 0;

    if (gem_id == 0)
        gem_dev_base = ZYNQMP_GEM_0_BASEADDR;
    if (gem_id == 1)
        gem_dev_base = ZYNQMP_GEM_1_BASEADDR;
    assert(gem_dev_base);

    gemu *gemu= &gm->gemu_dev_list[gem_id];

    gem_mapped_base = mmap(0, GEM_DEV_MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, gm->memfd,
                            gem_dev_base & ~(off_t)(gm->_pagesize - 1));
    if (gem_mapped_base == (void *) -1)
    {
        gemu_err("Can't map the GEM0 memory IO regs to user space. %s\n", strerror(errno));
        exit(0);
    }

    gem_base_addr = (void *)((u64)gem_mapped_base + (gem_dev_base & GEM_DEV_MAP_MASK));
    gemu_log("GEM%d base addr %p \n", gem_id, gem_base_addr);
    gemu_dev_configure(gemu, gem_id, (UINTPTR)gem_base_addr);
    gemu_clear_error(gemu);
    gemu_enable(gemu);
    gemu_dump_desc(gemu);
    //
}
#endif

#if 0
static ALWAYS_INLINE struct rte_mbuf *rte_mempool_pop(struct rte_mempool *mp) 
{
    gemu_assert(mp->cur_count > 0);
    int i = --mp->cur_count;

    mp->bufs_popped++;
    rte_mbuf *hdr = (rte_mbuf *)(mp->bufs[i].virt_addr);
    gemu_log("Allocted current buf count %d ", mp->cur_count);
    return (hdr);
}

static ALWAYS_INLINE void rte_mempool_push(struct rte_mempool *mp, uint64_t virt_addr, uint64_t phys_addr)
{
    gemu_assert(mp->cur_count < mp->num_bufs);

    rte_mbuf *hdr = (rte_mbuf *)virt_addr;

    mp->bufs[mp->cur_count].phys_addr = phys_addr;
    mp->bufs[mp->cur_count].virt_addr = virt_addr;
    mp->bufs_pushed++;

    hdr->pkt_len = 0;

    int i = mp->cur_count;
    mp->cur_count++;
    gemu_log("Returned buf buf count %d ", mp->cur_count);
}
#endif

#if 0
static ALWAYS_INLINE void rte_mempool_pop_rxq(struct gemu *gemu, struct gemu_rx_q *rx_q, uint64_t *virt_addr, uint64_t *phys_addr)
{
    gemu_assert(phys_addr);
    gemu_assert(virt_addr);
    rte_mempool *mp=&rx_q->mp;

    rte_mempool_pop(gemu, mp, virt_addr, phys_addr);
}

static ALWAYS_INLINE void rte_mempool_push_txq(struct gemu *gemu, struct gemu_tx_q *tx_q, uint64_t virt_addr, uint64_t phys_addr)
{
    rte_mempool *mp=&tx_q->mp;
    rte_mempool_push(gemu, mp, virt_addr, phys_addr);
}

#endif

#endif // __GEMU_TESTAPP_H__
