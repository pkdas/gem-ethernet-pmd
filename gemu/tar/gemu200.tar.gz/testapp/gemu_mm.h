#ifndef __GEMU_MM_H__
#define __GEMU_MM_H__

#include "gemu_types.h"

typedef u64 phys_addr_t;
typedef uint64_t rte_iova_t;

typedef struct __attribute__((packed)) rte_mbuf
{
    void        *buf_addr;
    rte_iova_t  buf_iova;
    struct 
    {
        u16 data_off;
	u16 refcnt;
	u16 nb_segs;
	u16 port;
    };
    u64 ol_flags;
    u32 pkt_len;
    u32 dummy;
    u16 data_len;
    u16 vlan_tci;
    u16 vlan_tci_outer;
    u16 buf_len;

    struct rte_mempool *pool;
    struct rte_mbuf *next;
} rte_mbuf;

SIZE_ASSERT(rte_mbuf, 64);

typedef struct buf_addr
{
    uint64_t virt_addr; 
    uint64_t phys_addr;
}buf_addr;

typedef struct rte_mempool 
{
    buf_addr *bufs;
    struct gemu_rx_q *rx_q; // each rx-pool is assigned to a gem device and rx-q
    u32 num_bufs;
    u32 cur_count;
    u32 bufs_popped;
    u32 bufs_pushed;

    u64 bufmem_start;
    u64 bufmem_end;
    u64 bufmem_size;
    u32 buf_size;
}rte_mempool;

void rte_mempool_init();


#endif // __GEMU_MM_H__
