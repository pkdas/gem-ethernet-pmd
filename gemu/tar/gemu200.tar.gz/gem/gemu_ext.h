#ifndef __GEMU_EXT_H__
#define __GEMU_EXT_H__

struct gemu;
struct rte_mempool;

void *rte_mempool_alloc_bdmem(u32 memsize);
void  rte_mempool_free_bdmem(void *p, u32 memsize);

void rte_mempool_alloc_bufmem(struct gemu *gemu, struct rte_mempool *mp, int rx_bd_count);
void rte_mempool_free_bufmem(struct rte_mempool *mp);

#endif // __GEMU_EXT_H__
