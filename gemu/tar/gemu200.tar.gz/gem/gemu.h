#ifndef __GEMU_H__
#define __GEMU_H__

#include <assert.h>
#include "gemu_gemdefs.h"
#include "gemu_bd.h"

struct rte_mempool;
struct gemu;

// PK FIXME remove these
#ifndef TRUE
#  define TRUE        1U
#endif

#ifndef FALSE
#  define FALSE        0U
#endif

#ifndef NULL
#define NULL        0U
#endif
//-------------

typedef enum {
    GEMU_SUCCESS=0,
    GEMU_FAILURE
} gemu_status;

typedef enum {
    GEM_DEVICE_0 = 0,
    GEM_DEVICE_1,
    GEM_MAX_DEVICES
} GEM_DEVICE_NUMS;

#define ZYNQMP_GEM_0_BASEADDR 0xFF0B0000
#define ZYNQMP_GEM_1_BASEADDR 0xFF0C0000
#define ZYNQMP_GEM_2_BASEADDR 0xFF0D0000
#define ZYNQMP_GEM_3_BASEADDR 0xFF0E0000

#define GEM_DEV_MAP_SIZE 4096
#define GEM_DEV_MAP_MASK (GEM_DEV_MAP_SIZE - 1)
#define GEM_PROMISC_OPTION               0x00000001U
#define GEM_FRAME1536_OPTION             0x00000002U
#define GEM_VLAN_OPTION                  0x00000004U
#define GEM_FLOW_CONTROL_OPTION          0x00000010U
#define GEM_FCS_STRIP_OPTION             0x00000020U
#define GEM_FCS_INSERT_OPTION            0x00000040U
#define GEM_LENTYPE_ERR_OPTION           0x00000080U
#define GEM_TRANSMITTER_ENABLE_OPTION    0x00000100U
#define GEM_RECEIVER_ENABLE_OPTION       0x00000200U
#define GEM_BROADCAST_OPTION             0x00000400U
#define GEM_MULTICAST_OPTION             0x00000800U
#define GEM_RX_CHKSUM_ENABLE_OPTION      0x00001000U
#define GEM_TX_CHKSUM_ENABLE_OPTION      0x00002000U
#define GEM_JUMBO_ENABLE_OPTION          0x00004000U
#define GEM_SGMII_ENABLE_OPTION          0x00008000U

#define GEM_DEFAULT_OPTIONS                     \
    ((u32)GEM_FLOW_CONTROL_OPTION |                  \
     (u32)GEM_FCS_INSERT_OPTION |                    \
     (u32)GEM_FCS_STRIP_OPTION |                     \
     (u32)GEM_BROADCAST_OPTION |                     \
     (u32)GEM_LENTYPE_ERR_OPTION |                   \
     (u32)GEM_TRANSMITTER_ENABLE_OPTION |            \
     (u32)GEM_RECEIVER_ENABLE_OPTION |               \
     (u32)GEM_RX_CHKSUM_ENABLE_OPTION |              \
     (u32)GEM_TX_CHKSUM_ENABLE_OPTION)

#define GEM_MTU             1500U    /* max MTU size of Ethernet frame */

// PK FIXME enable jumbo but use 1500 MTU for now 
// #define GEM_MTU_JUMBO    10240U    /* max MTU size of jumbo frame */
#define GEM_MTU_JUMBO       1500U    /* max MTU size of jumbo frame */
#define GEM_HDR_SIZE        14U    /* size of Ethernet header */
#define GEM_HDR_VLAN_SIZE   18U    /* size of Ethernet header with VLAN */
#define GEM_TRL_SIZE        4U    /* size of Ethernet trailer (FCS) */
#define GEM_MAX_FRAME_SIZE       (GEM_MTU + GEM_HDR_SIZE + GEM_TRL_SIZE)
#define GEM_MAX_VLAN_FRAME_SIZE  (GEM_MTU + GEM_HDR_SIZE +  GEM_HDR_VLAN_SIZE + \
                                       GEM_TRL_SIZE)
#define GEM_MAX_VLAN_FRAME_SIZE_JUMBO  (GEM_MTU_JUMBO + GEM_HDR_SIZE + \
                                        GEM_HDR_VLAN_SIZE + GEM_TRL_SIZE)

/* DMACR Bust length hash defines */
#define GEM_SINGLE_BURST    0x00000001
#define GEM_4BYTE_BURST     0x00000004
#define GEM_8BYTE_BURST     0x00000008
#define GEM_16BYTE_BURST    0x00000010

#define GEM_MAX_RX_QUEUES  2
#define GEM_MAX_TX_QUEUES  2

typedef struct gemu_config
{
    char name[64];    
    char ifname[64];
    int port_id;
    unsigned int device_id; 
    UINTPTR base_addr;
    u8 mac_addr[6];
    u32 rx_bd_count;
    u32 tx_bd_count;
    u8 ip4_addr[4];
    u8 next_hop_mac[6];
} gemu_config;

// 32 bit stats only for now 
typedef struct gemu_rx_stats
{
    u32 rx_pi_updated;
    u32 rx_pi_wrap;
    u32 rx_pi_update_q_full;
    u32 rx_pi_no_update_q_full;
    u32 rx_pi_update_max;
    u32 rx_pi_single_read;
    u32 rx_pi_burst_read;
    u32 rx_ci_wrap;
    u32 rx_ci_updated;
    u32 rx_ci_all;
    u32 rx_pi_count;
    u32 max_rx_q_len;
    u32 rx_q_len_16;

    u32 bufs_alloc_rx_refill;
    u32 bufs_pushed_tossed_arp_pkts; 
    u32 bufs_pushed_tossed_ip_pkts; 
    u32 bufs_pushed_tossed_non_ip_pkts; 
} gemu_rx_stats;

typedef struct gemu_tx_stats
{
    u32 tx_bd_poll;
    u32 tx_ci_count;
    u32 tx_ci_single_complete;
    u32 tx_ci_burst_complete;
    u32 tx_q_len_max;
    u32 tx_ci_updated;
    u32 tx_ci_updated_all;
    u32 tx_err;
    u32 tx_pkts;
    u32 tx_start;
    u32 tx_queue_full;
    u32 tx_status_go;
    u32 tx_status_complete;
    u32 tx_status_err;
    u32 tx_added;
    u32 fwded_tx_added;
    u32 tx_complete;
    u32 max_tx_q_len;
    u32 tx_q_len_16;

    u32 bufs_pushed_tx_complete;
    u32 bufs_pushed_fwd_complete; 
} gemu_tx_stats;

typedef struct gemu_stats
{
    u32 rx_pkts_tossed;
    u32 tcp_pkts_rxed;
    u32 udp_pkts_rxed;
    u32 icmp_pkts_rxed;

    u32 ip_pkts_fwded;
    u32 tcp_pkts_fwded;
    u32 udp_pkts_fwded;
    u32 icmp_echo_req_fwded;
    u32 icmp_echo_reply_fwded;

    u32 rx_arp_pkts;
    u32 rx_ip_pkts;
    u32 rx_nonip_pkts;
    u32 rx_bufs_freed;

    u32 icmp_echo_requests;
    u32 icmp_echo_replies;
    u32 arp_req_recvd;
    u32 arp_req_host_ip_recvd;
    u32 arp_reply_sent;
} gemu_stats;

typedef struct gemu_rx_q
{
    struct gemu *gemu;
    int rx_q_id;
    pthread_spinlock_t lock;
    gemu_desc *rx_bd_mem;
    UINTPTR phys_rx_bd_mem;
    u32 rx_bd_memsize;
    u32 rx_bd_count; 
    struct rte_eth_rxconf rxconf;

    struct rte_mempool mp;
    gemu_hbd rx_hbds[GEMU_MAX_HBDS+4];

    u32 rx_pi;
    u32 rx_ci;

    struct rte_mbuf *rx_vector[GEMU_RX_VECTOR_SIZE];
    u32 rx_vector_size;

    gemu_rx_stats rx_stats;
} gemu_rx_q;

typedef struct gemu_tx_q
{
    struct gemu *gemu;
    int tx_q_id;
    pthread_spinlock_t lock;
    gemu_desc *tx_bd_mem;
    UINTPTR phys_tx_bd_mem;
    u32 tx_bd_memsize;
    u32 tx_bd_count; 
    struct rte_eth_txconf txconf;

    u32 tx_pkt_id;

    gemu_hbd tx_hbds[GEMU_MAX_HBDS+4];

    u32 tx_pi;
    u32 tx_ci;
    u32 tx_prev_pi;
    u32 tx_prev_ci;

    struct rte_mbuf *tx_vector[GEMU_TX_VECTOR_SIZE];
    u32 tx_vector_size;

    gemu_tx_stats tx_stats;
} gemu_tx_q;

struct gemu_main;

typedef struct gemu {
    struct gemu_main *gm;
    int started; 
    gemu_config config;    
    int lcore;
    int num_tx_queues;
    int num_rx_queues;

    void *app_data; // platform specific per device data

    gemu_rx_q rx_queues[GEM_MAX_RX_QUEUES];
    gemu_tx_q tx_queues[GEM_MAX_TX_QUEUES];

    u8  peer_mac[6];
    u8  my_mac[6];
 
    u32 version;
    u32 rx_buf_mask;
    u32 max_mtu_size;
    u32 max_frame_size;
    u32 max_vlan_frame_size;
    u32 max_queues;

    gemu_stats stats;
} gemu;

typedef struct gemu_main
{
    gemu gemu_dev_list[GEM_MAX_DEVICES]; 
    u32 _pagesize;
    int  memfd;
} gemu_main;

#define gemu_int_enable(gemu, mask)                            \
    gemu_write_reg((gemu)->config.base_addr,             \
             GEM_IER_OFFSET,                                     \
             ((mask) & GEM_IXR_ALL_MASK));

#define gemu_int_disable(gemu, mask)                           \
    gemu_write_reg((gemu)->config.base_addr,             \
             GEM_IDR_OFFSET,                                     \
             ((mask) & GEM_IXR_ALL_MASK));

#define gemu_int_qi_enable(gemu, queue, mask)                       \
    gemu_write_reg((gemu)->config.base_addr,             \
             gemu_get_qx_offset(INTQI_IER, queue),        \
             ((mask) & GEM_INTQ_IXR_ALL_MASK));

#define gemu_int_qi_disable(gemu, queue, mask)                      \
    gemu_write_reg((gemu)->config.base_addr,             \
             gemu_get_qx_offset(INTQI_IDR, queue),        \
             ((mask) & GEM_INTQ_IXR_ALL_MASK));

#define gemu_transmit(gemu)                              \
    gemu_write_reg((gemu)->config.base_addr,          \
             GEM_NWCTRL_OFFSET,                                     \
             (gemu_read_reg((gemu)->config.base_addr,          \
                      GEM_NWCTRL_OFFSET) | GEM_NWCTRL_STARTTX_MASK))

#define gemu_is_rx_csum(gemu)                                     \
    ((gemu_read_reg((gemu)->config.base_addr,             \
              GEM_NWCFG_OFFSET) & GEM_NWCFG_RXCHKSUMEN_MASK) != 0U     \
     ? TRUE : FALSE)

#define gemu_is_tx_csum(gemu)                                     \
    ((gemu_read_reg((gemu)->config.base_addr,              \
              GEM_DMACR_OFFSET) & GEM_DMACR_TCPCKSUM_MASK) != 0U       \
     ? TRUE : FALSE)


#define gemu_set_rx_watermark(gemu, High, Low)                     \
    gemu_write_reg((gemu)->config.base_addr,                \
             GEM_RXWATERMARK_OFFSET,                                        \
             (High & GEM_RXWM_HIGH_MASK) |  \
             ((Low << GEM_RXWM_LOW_SHFT_MSK) & GEM_RXWM_LOW_MASK) |)

#define gemu_get_rx_watermark(gemu)                     \
    gemu_read_reg((gemu)->config.base_addr,                \
            GEM_RXWATERMARK_OFFSET)

#define GEMU_GET_TX_Q(gemu, tx_queue_id); \
    gemu_tx_q *tx_q = &gemu->tx_queues[tx_queue_id];

#define GEMU_GET_RX_Q(gemu, rx_queue_id); \
    gemu_rx_q *rx_q = &gemu->rx_queues[rx_queue_id];

// Remove FIXME PK
#if 0
#define BIT(n)            (1U << n)
#define SET_BIT(x, n)     (x | BIT(n))
#define GET_BIT(x, n)     ((x >> n) & 1U)
#define CLEAR_BIT(x, n)   (x & (~BIT(n)))
#define GENMASK(h, l)     (((~0U) << (l)) & (~0U >> (sizeof(int) * 8 - 1 - (h))))
#endif

#ifdef GEMU_TESTAPP
static ALWAYS_INLINE void rte_mb() { asm volatile("dmb osh" : : : "memory"); }

static ALWAYS_INLINE void rte_wmb() { asm volatile("dmb oshst" : : : "memory"); }

static ALWAYS_INLINE void rte_rmb() { asm volatile("dmb oshld" : : : "memory"); }

static ALWAYS_INLINE void rte_smp_mb() { asm volatile("dmb ish" : : : "memory"); }

static ALWAYS_INLINE void rte_smp_wmb() { asm volatile("dmb ishst" : : : "memory"); }

static ALWAYS_INLINE void rte_smp_rmb() { asm volatile("dmb ishld" : : : "memory"); }
#endif

LONG gemu_cfg_initialize(gemu *gemu, gemu_config *cfg, UINTPTR effective_addr);
void gemu_set_queue_ptr(gemu *gemu, UINTPTR q_ptr, u8 queue_num, u16 direction);

gemu_config *gemu_lookup_config(int device_id);

LONG gemu_delete_hash(gemu *gemu, void *mac_addr);

LONG gemu_set_hash(gemu *gemu, void *mac_addr);
void gemu_clear_hash(gemu *gemu);
void gemu_get_hash(gemu *gemu, void *mac_addr);

void *gemu_mm_alloc(u32 memsize);
void gemu_mm_free(void *p, u32 memsize);

void gemu_bufmem_alloc(gemu *);
void gemu_bufmem_free(gemu *);

#endif // __GEMU_H__
