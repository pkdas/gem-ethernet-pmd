#ifndef __GEMU_GEMIO_H__
#define __GEMU_GEMIO_H__

#include <assert.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <sys/mman.h>
#include <unistd.h>
#include <errno.h>
#include <time.h>
#include <netinet/in.h>
#ifndef __USE_GNU
#define __USE_GNU
#endif
#include <pthread.h>

#include "gemu.h"
#include "gemu_device.h"

static void gemu_disable(gemu *gemu);
static int gemu_tx_status(gemu *gemu);

static ALWAYS_INLINE void gemu_dump_bytes(u8 *data, int num_bytes)
{
#ifdef GEMU_DEBUG
    for (int i=0; i < num_bytes; i++)
    {
        gemu_log("0x%0x ", data[i]);
        if (i && ((i+1) % 16)==0)
        {
            gemu_log("\n");
        }
    }
    gemu_log("\n");
#else
    data = data; 
    num_bytes = num_bytes;
#endif
}

static ALWAYS_INLINE void gemu_dump_rx_desc(gemu_desc *desc)
{
#ifdef GEMU_DEBUG
    gemu_bd_ex *bd=&desc->bd;
    gemu_bd *_bd=&desc->_bd;

    gemu_log("addr_lo 0x%0x status 0x%0x addr_hi 0x%0x w3 0x%0x wrap 0x%0x\n", 
            bd->addr_lo, bd->status, bd->addr_hi, (*_bd)[3], ((*_bd)[0] & GEM_RX_DESC_WRAP));

#else
    desc = desc;
#endif
    // RX desc WRAP word0 bit 1 0x2
}

static ALWAYS_INLINE void gemu_dump_tx_desc(gemu_desc *desc)
{
#ifdef GEMU_DEBUG
    gemu_bd_ex *bd=&desc->bd;
    gemu_bd *_bd=&desc->_bd;

    gemu_log("addr_lo 0x%0x status 0x%0x addr_hi 0x%0x w3 0x%0x wrap 0x%0x\n", 
            bd->addr_lo, bd->status, bd->addr_hi, (*_bd)[3], ((*_bd)[1] & GEM_TX_DESC_WRAP));

#else
    desc = desc;
#endif
    // TX desc WRAP word1 bit 30 0x40000000
}

static ALWAYS_INLINE int gemu_is_rx_desc_wrap(gemu_desc *rx_desc)
{
    gemu_bd *_bd=&rx_desc->_bd;

    if ((*_bd)[0] & GEM_RX_DESC_WRAP)
    {
        return 1;
    }

    return 0;
}

static ALWAYS_INLINE int gemu_is_tx_desc_wrap(gemu_desc *tx_desc)
{
    gemu_bd *_bd=&tx_desc->_bd;

    if ((*_bd)[1] & GEM_TX_DESC_WRAP)
    {
        return 1;
    }

    return 0;
}

static ALWAYS_INLINE void gemu_dump_rx_descs(gemu *gemu, int count)
{
#ifdef GEMU_DEBUG
    gemu_desc *rx_desc = (gemu_desc *)gemu->rx_bd_mem;
    u32 rx_desc_count=1;

    gemu_log("!!!!%s Dumping Rx-Descriptor list..\n", gemu->config.name); 
    gemu_log("________________________________\n"); 
    while (1)
    {
        gemu_log("RX-%d >>", rx_desc_count);
        gemu_dump_rx_desc(rx_desc);

        if (gemu_is_rx_desc_wrap(rx_desc))
        {
             gemu_log("RX_desc WRAP found rx-desc-count %d\n", rx_desc_count);
             break;
        }

        if (rx_desc_count == count)
        {
             gemu_log("Dumped rx-desc count %d\n", count);
             break;
        }
        rx_desc_count++;
        rx_desc++;

    }

    if (!count)
    {
        gemu_assert(rx_desc_count == gemu->rx_bd_count);
    }
#else
    gemu = gemu;
    count = count;
#endif
}

static ALWAYS_INLINE void gemu_dump_tx_descs(gemu *gemu, int count)
{
#ifdef GEMU_DEBUG
    gemu_desc *tx_desc = (gemu_desc *)gemu->tx_bd_mem;
    u32 tx_desc_count=1;

    gemu_log("!!!!%s Dumping Tx-Descriptor list..\n", gemu->config.name); 
    gemu_log("________________________________\n"); 
    while (1)
    {
        gemu_log("TX-%d >>", tx_desc_count);
        gemu_dump_tx_desc(tx_desc);

        if (gemu_is_tx_desc_wrap(tx_desc))
        {
            gemu_log("TX_desc WRAP found tx-desc-count %d\n", tx_desc_count);
            break;
        }

        if (tx_desc_count == count)
        {
             gemu_log("Dumped tx-desc count %d\n", count);
             break;
        }

        tx_desc_count++;
        tx_desc++;
    }

    if (!count)
    {
        gemu_assert(tx_desc_count == gemu->tx_bd_count);
    }
#else
    gemu = gemu;
    count = count;
#endif
}

static ALWAYS_INLINE void gemu_dump_desc(gemu *gemu)
{
    gemu_dump_rx_descs(gemu, 0);
    gemu_dump_tx_descs(gemu, 0);
}

static ALWAYS_INLINE int gemu_is_q_empty(u32 pi, u32 ci)
{
    return (pi==ci);
}

static ALWAYS_INLINE u32 gemu_num_entries_in_q(u32 pi, u32 ci, u32 max_entries)
{
    u32 num_entries = 0;

    if (pi >= ci)
    {
        num_entries = pi - ci;  
    }else
    {
        num_entries = max_entries + pi - ci;
    }

    gemu_assert(num_entries <= max_entries);

    return num_entries;
}

static ALWAYS_INLINE int gemu_is_q_full(u32 pi, u32 ci, u32 count)
{
    return (gemu_num_entries_in_q(pi, ci, count) == count);
}

static ALWAYS_INLINE int gemu_is_tx_q_full(gemu_tx_q *tx_q)
{
    return (gemu_is_q_full(tx_q->tx_pi, tx_q->tx_ci, tx_q->tx_bd_count));
}

static ALWAYS_INLINE int gemu_is_rx_q_full(gemu_rx_q *rx_q)
{
    return (gemu_is_q_full(rx_q->rx_pi, rx_q->rx_ci, rx_q->rx_bd_count)); 
}

static ALWAYS_INLINE u32 increment_index(u32 val, u32 count)
{
    if (++val > count)
        val = 0;

    return val;
}

#ifdef GEMU_TESTAPP
static ALWAYS_INLINE struct rte_mempool *gemu_get_pkt_mp(struct rte_mbuf *pkt)
{
    assert(pkt);
    struct rte_mempool *mp = pkt->pool;
    assert(mp);
    return mp;
}

static ALWAYS_INLINE gemu_rx_q *gemu_get_pkt_rx_q(struct rte_mbuf *pkt)
{
    struct rte_mempool *mp = gemu_get_pkt_mp(pkt);
    assert(mp->rx_q);
    return(mp->rx_q);
}

static ALWAYS_INLINE gemu *gemu_get_pkt_gemu(struct rte_mbuf *pkt)
{
    gemu_rx_q *rx_q = gemu_get_pkt_rx_q(pkt);
    assert(rx_q->gemu);
    return(rx_q->gemu);
}
#endif

static ALWAYS_INLINE int gemu_tx_pkt(gemu_tx_q *tx_q, struct rte_mbuf *tx_pkt)
{
    gemu_bd *tx_bd=0;
    gemu_hbd *tx_hbd=0;

    if (gemu_is_tx_q_full(tx_q))
    {
        tx_q->tx_stats.tx_queue_full++;
        return -1;
    }

    // pointing to invalid slot past the last entry, update to correct index to 0
    if (tx_q->tx_pi == tx_q->tx_bd_count)
    {
        tx_q->tx_pi = 0;
    }

    gemu_assert(tx_q->tx_pi < tx_q->tx_bd_count);

    tx_bd = (gemu_bd *)&tx_q->tx_bd_mem[tx_q->tx_pi];
    tx_hbd = &tx_q->tx_hbds[tx_q->tx_pi];
    gemu_assert(tx_hbd->bd_id == tx_q->tx_pi);

    gemu_assert(tx_bd);
    gemu_bd_set_addr_tx(tx_bd, rte_pktmbuf_iova(tx_pkt));
    gemu_assert((sizeof(struct rte_mbuf)+tx_pkt->pkt_len) <= tx_pkt->buf_len);
    
    gemu_bd_set_length(tx_bd, (tx_pkt->pkt_len));
    gemu_bd_set_last(tx_bd);

    gemu_assert(tx_hbd->desc == (gemu_desc *)tx_bd);

    tx_hbd->buf = (UINTPTR)tx_pkt;
    tx_hbd->pktmbuf_phys_addr = rte_pktmbuf_iova(tx_pkt);  

    tx_pkt->refcnt++; 

    tx_q->tx_pi = increment_index(tx_q->tx_pi, tx_q->tx_bd_count);

    // clearing tx used should be the last write on the desc and all writes must be finished
    rte_wmb();

    gemu_bd_clear_tx_used(tx_bd);
    return 0;
}


static ALWAYS_INLINE u16 gemu_tx_burst(gemu_tx_q *tx_q, struct rte_mbuf **tx_pkts, u16 nb_pkts)
{
    int i;
    int tx_err_count = 0;
    u16 tx_count = 0;
    gemu *gemu = tx_q->gemu;

    for (i=0; i < nb_pkts; i++)
    {
        if (gemu_tx_pkt(tx_q, tx_pkts[i]) == -1)
        {
            tx_q->tx_stats.tx_err++;
            tx_err_count++;
            //break;
            gemu_assert(!"GEM tx error");
        }else
        {
            tx_count++;
        }
    }

    if (tx_count) 
    {
        rte_wmb();
        gemu_transmit(gemu);
        tx_q->tx_stats.tx_start++;
    }

    tx_q->tx_stats.tx_pkts += tx_count;
    return tx_count;
}

static ALWAYS_INLINE u16 gemu_tx_vector(gemu_tx_q *tx_q) 
{
    struct rte_mbuf **tx_pkts = tx_q->tx_vector;
    int nb_pkts = tx_q->tx_vector_size;

    return (gemu_tx_burst(tx_q, tx_pkts, nb_pkts));
}

static ALWAYS_INLINE void gemu_complete_tx_bd(gemu_tx_q *tx_q, gemu_bd *tx_bd, gemu_hbd *tx_hbd)
{
    // return buf
    // reset tx_bd buf_addr
    // clear tx_bd status 

    tx_q->tx_stats.tx_complete++;

    gemu_desc *desc = (gemu_desc *)tx_bd;
    u32 bd_id = desc->bd.bd_id;

    gemu_assert(desc->bd.status & (GEM_TXBUF_LAST_MASK));

    // bd and hbd are in sync
    gemu_assert(bd_id == tx_hbd->bd_id);

    UINTPTR pktmbuf_phys_addr;
    gemu_assert(tx_hbd->buf);
    pktmbuf_phys_addr = gemu_bd_get_tx_buf_addr(tx_bd); 

    // all check success - clean up
    struct rte_mbuf *tx_pkt = (struct rte_mbuf *)tx_hbd->buf;
    //gemu_assert(tx_pkt->refcnt == 1);
    gemu_assert(tx_hbd->pktmbuf_phys_addr == pktmbuf_phys_addr);

    rte_pktmbuf_free(tx_pkt); 

    tx_hbd->buf = 0;
    gemu_bd_set_addr_tx(tx_bd, 0);

    // clear USED and LAST bits
    u32 status_before = desc->bd.status;
    desc->bd.status = GEM_TXBUF_USED_MASK | (status_before & GEM_TXBUF_WRAP_MASK); 

    rte_wmb(); 
}

static ALWAYS_INLINE void gemu_complete_rx_bd(gemu_rx_q *rx_q, gemu_bd *rx_bd, gemu_hbd *rx_hbd)
{
    //gemu *gemu = rx_q->gemu;

    struct rte_mbuf *mbuf = rte_pktmbuf_alloc(&rx_q->mp);
    // PK FIXME update rx-refill buf error count
    assert(mbuf);

    rx_q->rx_stats.bufs_alloc_rx_refill++;

    ////
    gemu_desc *desc = (gemu_desc *)rx_bd;
    u32 rx_bd_addr_lo=desc->bd.addr_lo;
    u32 bd_id=desc->bd.bd_id;

    // bd and hbd are in sync
    gemu_assert(bd_id == rx_hbd->bd_id);

    // verify that USED bit is set
    gemu_assert(rx_bd_addr_lo & GEM_RXBUF_NEW_MASK);
    gemu_assert(desc->bd.status & (GEM_RXBUF_EOF_MASK | GEM_RXBUF_SOF_MASK));

    // if this is the last BD, verify WRAP bit
    if (rx_hbd->bd_id == (rx_q->rx_bd_count-1))
    {
        gemu_assert(rx_bd_addr_lo & GEM_RXBUF_WRAP_MASK);
    }
    
    gemu_bd_set_addr_rx(rx_bd, rte_pktmbuf_iova(mbuf)); 

    rte_wmb();

    rx_hbd->buf = (UINTPTR)mbuf;
    rx_hbd->pktmbuf_phys_addr = rte_pktmbuf_iova(mbuf);
    mbuf->refcnt++; 

    u32 addr_lo_before = desc->bd.addr_lo;

    // clear the USED bit - since we have updated the rx_buf in the desc
    desc->bd.addr_lo = addr_lo_before & ~GEM_RXBUF_NEW_MASK;
}


// acting on behalf of GEM

// tx-q
// - pi is updated by gemu tx request by applicaiton
// - ci is updated by GEM by updating the BD tx completion status
 
// look at tx-complete flag in current TX-BD update ci
static ALWAYS_INLINE u32 gemu_update_tx_ci(gemu_tx_q *tx_q)
{
#define TX_BD_MAX_READ 1 

    gemu *gemu = tx_q->gemu;

    u32 tx_bd_status[TX_BD_MAX_READ] = {0};
    u32 curr_ci = tx_q->tx_ci;   

    // if there is any pending tx completion poll tx-bd status

    // last one is an empty slot, need to to skip check if we increment
    u32 tx_q_len =  gemu_num_entries_in_q(tx_q->tx_pi, tx_q->tx_ci, tx_q->tx_bd_count);

    if (tx_q_len == 0) 
    {
        return curr_ci;
    } 

    if (tx_q_len > tx_q->tx_stats.max_tx_q_len)
    {
        tx_q->tx_stats.max_tx_q_len = tx_q_len;
    }
    if (tx_q_len > 16)
    {
        tx_q->tx_stats.tx_q_len_16++;
    }

    tx_q->tx_stats.tx_bd_poll++;

    if (curr_ci == tx_q->tx_bd_count)
    {
        // this is a special case, pointing to unused slot at index tx_bd_count
        curr_ci = 0; 
    }

#if 0
    if (tx_q_len > GEMU_TX_VECTOR_SIZE)
    {
        tx_q_len = GEMU_TX_VECTOR_SIZE;
        tx_q->tx_stats.tx_q_len_max++;
    } 
#endif

    int ci_count = 0;
    while (1)
    {
        int updated=0;
#if 0
        if (likely(curr_ci+TX_BD_MAX_READ <= tx_q_len) && 
            likely((curr_ci+TX_BD_MAX_READ) < tx_q->tx_bd_count))
        {
            int i = 0;
            while (i < TX_BD_MAX_READ)
            {
                tx_bd_status[i] = tx_q->tx_bd_mem[curr_ci+i].bd.status;
                i++;
            }

            i=TX_BD_MAX_READ;
            while (i && !(tx_bd_status[i-1] & GEM_TXBUF_USED_MASK))
            {
                i--; 
            }     
            if (i > 1)
            {
                tx_q->tx_stats.tx_ci_burst_complete++;
            }
            if (i == 1)
            {
                tx_q->tx_stats.tx_ci_single_complete++;
            }
            if (i)
            {
                gemu_assert(tx_bd_status[i-1] & GEM_TXBUF_LAST_MASK);
                updated = 1;
            }
            curr_ci += i;
            tx_q_len -= i;
            ci_count += i;
        } else
#endif
        {
            // rte_rmb();  do we need this before or after
            tx_bd_status[0] = tx_q->tx_bd_mem[curr_ci].bd.status;
            if (tx_bd_status[0] & GEM_TXBUF_USED_MASK) 
            {
                tx_q->tx_stats.tx_ci_single_complete++;
                updated = 1;
                gemu_assert(tx_bd_status[0] & GEM_TXBUF_LAST_MASK);

                if (curr_ci++ == (tx_q->tx_bd_count-1))
                {
                    // last entry - check wrap bit for consistency
                    gemu_assert(tx_bd_status[0] & GEM_TXBUF_WRAP_MASK);
                }
                tx_q_len -= 1;
                ci_count += 1;
            }
        }

        if ((!updated) || (!tx_q_len))
        {
            break;
        }

    }

    if (tx_q->tx_ci != curr_ci)
    {
        gemu_log("%s tx-q %d updated tx ci curr_ci %d prev_ci %d\n", gemu->config.name, tx_q->tx_q_id, curr_ci, tx_q->tx_ci);
        tx_q->tx_stats.tx_ci_updated++;
    }

    tx_q->tx_stats.tx_ci_count += ci_count;

    if (!tx_q_len)
    {
        gemu_tx_status(gemu);
        tx_q->tx_stats.tx_ci_updated_all++;
    }

    tx_q->tx_ci = curr_ci;
    return (curr_ci);
}

// rx-q
// - pi is updated by GEM by updating the BD rx completion status
// - ci is updated by gemu by applicaiton rx processing

// look at rx-complete flag in current RX-BD and update pi
static ALWAYS_INLINE u32 gemu_update_rx_pi(gemu_rx_q *rx_q)
{
    gemu *gemu = rx_q->gemu;
    gemu = gemu;

#define RX_BD_MAX_READ 1
    u32 rx_bd_addr_lo[RX_BD_MAX_READ] = {0};
    u32 curr_pi = rx_q->rx_pi;   

    u32 rx_q_len =  gemu_num_entries_in_q(rx_q->rx_pi, rx_q->rx_ci, rx_q->rx_bd_count);
    gemu_assert(rx_q_len <= rx_q->rx_bd_count);
    // rx_queue full no update
    if (rx_q_len == rx_q->rx_bd_count)
    {
        gemu_log("update_rx_pi - queue full pi=%d ci=%d\n", curr_pi, rx_q->rx_ci);
        rx_q->rx_stats.rx_pi_no_update_q_full++;
        return curr_pi;
    }

    if (curr_pi == rx_q->rx_bd_count)
    {
        gemu_log("update_rx_pi - resetting rx_pi to 0\n");
        curr_pi = 0; 
        rx_q->rx_pi = curr_pi;
        rx_q->rx_stats.rx_pi_wrap++;
    }

    int pi_count = 0;
    int updated = 0;
    while (1)
    {
        updated=0;
#if 0
        if (likely((curr_pi+RX_BD_MAX_READ-1) < rx_q->rx_bd_count)  && 
            ((rx_q_len+RX_BD_MAX_READ) <= rx_q->rx_bd_count) &&
            ((pi_count+RX_BD_MAX_READ) <= GEMU_RX_VECTOR_SIZE))
        {
            gemu_assert((curr_pi+RX_BD_MAX_READ-1) < rx_q->rx_bd_count);
            int i = 0;
            while (i < RX_BD_MAX_READ)
            {
                rx_bd_addr_lo[i] = rx_q->rx_bd_mem[curr_pi+i].bd.addr_lo;
                i++;
            }

            i=RX_BD_MAX_READ;
            while (i && !(rx_bd_addr_lo[i-1] & GEM_RXBUF_NEW_MASK))
            {
                i--; 
            }     
            if (i > 1)
            {
                rx_q->rx_stats.rx_pi_burst_read++;
            }
            if (i == 1)
            {
                rx_q->rx_stats.rx_pi_single_read++;
            }
            if (i)
            {
                updated = 1;
                gemu_log("rx-pi updated by i %d\n", i);
            }
            curr_pi += i;
            pi_count += i;
        } else
#endif
        {
            gemu_assert(curr_pi < rx_q->rx_bd_count);

            // rte_rmb(); do we need this before or after
            rx_bd_addr_lo[0] = rx_q->rx_bd_mem[curr_pi].bd.addr_lo;

            if (rx_bd_addr_lo[0] & GEM_RXBUF_NEW_MASK)
            { 
                rx_q->rx_stats.rx_pi_single_read++;
                updated = 1;
                gemu_log("rx-pi updated by 1 only\n");
                pi_count += 1;
                if (curr_pi++ == (rx_q->rx_bd_count-1))
                {
                    // last entry - check wrap bit for consistency
                    gemu_assert(rx_bd_addr_lo[0] & GEM_RXBUF_WRAP_MASK);
                }
            }
        }

        if (!updated)
        {
            break;
        } else
        {
            rx_q->rx_stats.rx_pi_updated++;
        }

        gemu_assert(pi_count <= GEMU_RX_VECTOR_SIZE);
        if (pi_count == GEMU_RX_VECTOR_SIZE)
        {
            rx_q->rx_stats.rx_pi_update_max++;
            break;
        }
        gemu_assert((rx_q_len + pi_count) <= rx_q->rx_bd_count);

        // rx-q full
        if (rx_q_len + pi_count == rx_q->rx_bd_count)
        {
            rx_q->rx_stats.rx_pi_update_q_full++;
            break;
        }

        if (curr_pi == rx_q->rx_bd_count)
        {
            gemu_log("update_rx_pi - B - resetting rx_pi to 0\n");
            curr_pi = 0; 
            rx_q->rx_stats.rx_pi_wrap++;
        }
    }

    if (rx_q->rx_pi != curr_pi)
    {
        gemu_log("%s rx_q %d updated pi curr_pi %d prev_pi %d\n", gemu->config.name, rx_q->rx_q_id, curr_pi, rx_q->rx_pi);
    } else
    {
        //gemu_log("%s rx-pi is not updated\n", gemu->config.name);
    }

    rx_q->rx_stats.rx_pi_count += pi_count;
    rx_q->rx_pi = curr_pi;
    return (curr_pi);
}

static ALWAYS_INLINE LONG gemu_tx_complete(gemu_tx_q *tx_q)
{
    gemu *gemu = tx_q->gemu;
    LONG status = GEMU_SUCCESS;

    u32 curr_ci = tx_q->tx_ci;
    u32 prev_ci = tx_q->tx_prev_ci;

    if (prev_ci == curr_ci)
    {
        return status;
    }

    if (prev_ci == tx_q->tx_bd_count)
    {
        prev_ci = 0; 
    }
   
    while (prev_ci != curr_ci)
    {
        gemu_desc *desc = (gemu_desc *)&tx_q->tx_bd_mem[prev_ci];
        gemu_hbd  *hbd = &tx_q->tx_hbds[prev_ci];
     
        gemu_assert(desc);
        gemu_assert(hbd);
        gemu_assert(hbd->desc->bd.bd_id == prev_ci);
        gemu_assert(hbd->desc->bd.addr_lo == desc->bd.addr_lo);
        gemu_assert(hbd->desc->bd.addr_hi == desc->bd.addr_hi);
        gemu_assert(hbd->desc->bd.bd_id == desc->bd.bd_id);

        struct rte_mbuf *mbuf = (struct rte_mbuf *)hbd->buf;
        gemu_assert(mbuf);
        u64 phys_bd_buf_addr = ((u64)desc->bd.addr_lo | ((u64)(desc->bd.addr_hi) << 32));
        gemu_assert((mbuf->buf_iova + mbuf->data_off) == phys_bd_buf_addr); 

        gemu_complete_tx_bd(tx_q, (gemu_bd *)desc, hbd);  
        prev_ci = increment_index(prev_ci, tx_q->tx_bd_count);
    }

    if (tx_q->tx_prev_ci != prev_ci)
    {
        gemu_log("%s update tx_prev_ci, new-tx-prev_ci=%d old-tx-prev_ci=%d\n", gemu->config.name, prev_ci, tx_q->tx_prev_ci);
    }

    tx_q->tx_prev_ci = prev_ci;
  
    return (status);
}

static ALWAYS_INLINE LONG gemu_rx_complete(gemu_rx_q *rx_q)
{
    gemu *gemu = rx_q->gemu;
    LONG status = GEMU_SUCCESS;

    u32 curr_pi = rx_q->rx_pi;
    u32 curr_ci = rx_q->rx_ci;

    u32 rx_q_len =  gemu_num_entries_in_q(rx_q->rx_pi, rx_q->rx_ci, rx_q->rx_bd_count);
    gemu_assert(rx_q_len <= rx_q->rx_bd_count);

    if (!rx_q_len)
    {
        //gemu_log("update_rx_pi - queue empty ci=%d\n", curr_ci);
        return status;
    }

    if (rx_q_len > rx_q->rx_stats.max_rx_q_len)
    {
        rx_q->rx_stats.max_rx_q_len = rx_q_len;
    }
    if (rx_q_len > 16)
    {
        rx_q->rx_stats.rx_q_len_16++;
    }

    if (curr_ci == rx_q->rx_bd_count)
    {
        gemu_log("rx_complete - resetting rx_ci to 0\n");
        curr_ci = 0; 
        rx_q->rx_ci = curr_ci;
        rx_q->rx_stats.rx_ci_wrap++;
    }

    u32 ci_count = 0;
    while (curr_ci != curr_pi)
    {
        gemu_assert(curr_ci < rx_q->rx_bd_count);
        gemu_desc *desc = (gemu_desc *)&rx_q->rx_bd_mem[curr_ci];
        gemu_hbd  *hbd = &rx_q->rx_hbds[curr_ci];
     
        gemu_assert(desc);
        gemu_assert(hbd);
        gemu_assert(hbd->desc->bd.bd_id == curr_ci);
        gemu_assert((hbd->desc->bd.addr_lo & GEM_RXBUF_ADD_MASK) == (desc->bd.addr_lo & GEM_RXBUF_ADD_MASK));
        gemu_assert(hbd->desc->bd.addr_hi == desc->bd.addr_hi);
        gemu_assert(hbd->desc->bd.bd_id == desc->bd.bd_id);

        struct rte_mbuf *mbuf = (struct rte_mbuf *)hbd->buf;
        gemu_assert(mbuf);

        u64 phys_bd_buf_addr = ((u64)(desc->bd.addr_lo & GEM_RXBUF_ADD_MASK) | \
                                                          ((u64)(desc->bd.addr_hi) << 32));
        gemu_assert(rte_pktmbuf_iova(mbuf) == phys_bd_buf_addr); 

        gemu_assert(rx_q->rx_vector_size < GEMU_RX_VECTOR_SIZE);
        gemu_dump_rx_desc(desc);

        mbuf->pkt_len = gemu_bd_get_length(desc);

        rx_q->rx_vector[rx_q->rx_vector_size++] = (struct rte_mbuf *)mbuf;

        gemu_complete_rx_bd(rx_q, (gemu_bd *)desc, hbd);  

        ci_count++;
        curr_ci++;

        if (ci_count == rx_q_len)
        {
            rx_q->rx_stats.rx_ci_all++;
            break;
        }

        if (curr_ci == rx_q->rx_bd_count)
        {
            gemu_log("rx_complete - resetting rx_ci to 0\n");
            curr_ci = 0; 
            rx_q->rx_stats.rx_ci_wrap++;
        }
    }

    gemu_assert(ci_count == rx_q_len);

    if (rx_q->rx_ci != curr_ci)
    {
        gemu_log("%s rx_q %d update ci, curr_ci=%d prev_ci=%d\n", gemu->config.name, rx_q->rx_q_id, curr_ci, rx_q->rx_ci);
        rx_q->rx_stats.rx_ci_updated++;
    }

    rx_q->rx_ci = curr_ci;

    return (status);
}

// returns number of pkts received
static ALWAYS_INLINE u16 gemu_rx_burst(gemu_rx_q *rx_q, struct rte_mbuf **bufs, uint16_t nb_bufs)
{
    gemu *gemu = rx_q->gemu;
    LONG status = GEMU_SUCCESS;
    u16 pkt_count = 0;

    u32 curr_pi = rx_q->rx_pi;
    u32 curr_ci = rx_q->rx_ci;

    u32 rx_q_len =  gemu_num_entries_in_q(rx_q->rx_pi, rx_q->rx_ci, rx_q->rx_bd_count);
    gemu_assert(rx_q_len <= rx_q->rx_bd_count);

    if (!rx_q_len)
    {
        //gemu_log("update_rx_pi - queue empty ci=%d\n", curr_ci);
        return status;
    }

    if (rx_q_len > rx_q->rx_stats.max_rx_q_len)
    {
        rx_q->rx_stats.max_rx_q_len = rx_q_len;
    }
    if (rx_q_len > 16)
    {
        rx_q->rx_stats.rx_q_len_16++;
    }

    if (curr_ci == rx_q->rx_bd_count)
    {
        gemu_log("rx_complete - resetting rx_ci to 0\n");
        curr_ci = 0; 
        rx_q->rx_ci = curr_ci;
        rx_q->rx_stats.rx_ci_wrap++;
    }

    u32 ci_count = 0;
    while ((curr_ci != curr_pi) && (pkt_count < nb_bufs))
    {
        gemu_assert(curr_ci < rx_q->rx_bd_count);
        gemu_desc *desc = (gemu_desc *)&rx_q->rx_bd_mem[curr_ci];
        gemu_hbd  *hbd = &rx_q->rx_hbds[curr_ci];
     
        gemu_assert(desc);
        gemu_assert(hbd);
        gemu_assert(hbd->desc->bd.bd_id == curr_ci);
        gemu_assert((hbd->desc->bd.addr_lo & GEM_RXBUF_ADD_MASK) == (desc->bd.addr_lo & GEM_RXBUF_ADD_MASK));
        gemu_assert(hbd->desc->bd.addr_hi == desc->bd.addr_hi);
        gemu_assert(hbd->desc->bd.bd_id == desc->bd.bd_id);

        struct rte_mbuf *mbuf = (struct rte_mbuf *)hbd->buf;
        gemu_assert(mbuf);

        u64 phys_bd_buf_addr = ((u64)(desc->bd.addr_lo & GEM_RXBUF_ADD_MASK) | \
                                                          ((u64)(desc->bd.addr_hi) << 32));
        gemu_assert((mbuf->buf_iova+mbuf->data_off) == phys_bd_buf_addr); 

        gemu_dump_rx_desc(desc);

        mbuf->pkt_len = gemu_bd_get_length(desc);

        bufs[pkt_count++] = (struct rte_mbuf *)mbuf;

        gemu_complete_rx_bd(rx_q, (gemu_bd *)desc, hbd);  

        ci_count++;
        curr_ci++;

        if (ci_count == rx_q_len)
        {
            rx_q->rx_stats.rx_ci_all++;
            break;
        }

        if (curr_ci == rx_q->rx_bd_count)
        {
            gemu_log("rx_complete - resetting rx_ci to 0\n");
            curr_ci = 0; 
            rx_q->rx_stats.rx_ci_wrap++;
        }
    }

    if (rx_q->rx_ci != curr_ci)
    {
        gemu_log("%s rx_q %d update ci, curr_ci=%d prev_ci=%d\n", gemu->config.name, rx_q->rx_q_id, curr_ci, rx_q->rx_ci);
        rx_q->rx_stats.rx_ci_updated++;
    }

    rx_q->rx_ci = curr_ci;

    return (pkt_count);
}

static ALWAYS_INLINE LONG gemu_configure_queue_ptrs(gemu *gemu)
{
    assert(gemu->num_tx_queues);
    assert(gemu->num_rx_queues);

    gemu_tx_q *tx_q = &gemu->tx_queues[0];
    gemu_rx_q *rx_q = &gemu->rx_queues[0];

    // receive q 0x18 lo32
    gemu_write_reg(gemu->config.base_addr, 0x00000018, (u32)rx_q->rx_hbds[0].phys_desc & 0xFFFFFFFF);
    // transmit q 0x1C lo32
    gemu_write_reg(gemu->config.base_addr, 0x0000001C, (u32)tx_q->tx_hbds[0].phys_desc & 0xFFFFFFFF);

    // receive q  0x4D4 hi32
    gemu_write_reg(gemu->config.base_addr, 0x000004D4, (u32)((rx_q->rx_hbds[0].phys_desc >> 32) & 0xFFFFFFFF));
    // transmit q  0x4C8 hi32
    gemu_write_reg(gemu->config.base_addr, 0x000004C8, ((u32)(tx_q->tx_hbds[0].phys_desc >> 32) & 0xFFFFFFFF));

    if (gemu->num_tx_queues > 1)
    {
        assert(gemu->num_tx_queues == 2);
        gemu_tx_q *tx_q1 = &gemu->tx_queues[1];

        // transmit q1 0x440
        gemu_write_reg(gemu->config.base_addr, 0x00000440, (u32)tx_q1->tx_hbds[0].phys_desc & 0xFFFFFFFF);

        // no upper 32bit add for q1 ptr must be same as q0?
        assert(((u32)(tx_q->tx_hbds[0].phys_desc >> 32) & 0xFFFFFFFF) == ((u32)(tx_q1->tx_hbds[0].phys_desc >> 32) & 0xFFFFFFFF));
    }

    if (gemu->num_rx_queues > 1)
    {
        assert(gemu->num_rx_queues == 2);
        gemu_rx_q *rx_q1 = &gemu->rx_queues[1];

        // receive q1 0x480
        gemu_write_reg(gemu->config.base_addr, 0x00000480, (u32)rx_q1->rx_hbds[1].phys_desc & 0xFFFFFFFF);

        // no upper 32bit add for q1 ptr must be same as q0?
        assert(((u32)(rx_q->rx_hbds[0].phys_desc >> 32) & 0xFFFFFFFF) == ((u32)(rx_q1->rx_hbds[1].phys_desc >> 32) & 0xFFFFFFFF));
    }

    // dma rxbuf q1 0x4A0
    gemu_write_reg(gemu->config.base_addr, 0x000004A0, 0x18);  // 1536B not jumbo frame 0xA0 10240B
}

// initialize all rx_bds 
static void gemu_init_rx_bds(gemu *gemu, gemu_rx_q *rx_q)
{
    gemu_bd *rx_bd = (gemu_bd *)rx_q->rx_bd_mem;
    UINTPTR phys_rx_bd = rx_q->phys_rx_bd_mem;
    struct rte_mempool *mp = &rx_q->mp;

    rx_q->rx_pi = 0;
    rx_q->rx_ci = 0;

    gemu_assert(rx_bd);
    gemu_log("GEM %s rx_q %d setting up rx bds\n", gemu->config.name, rx_q->rx_q_id);

    memset(rx_q->rx_hbds, 0, sizeof(rx_q->rx_hbds));

    u32 i;
    for (i=0; i < rx_q->rx_bd_count; i++)
    {
        struct rte_mbuf *mbuf = rte_pktmbuf_alloc(mp);
        gemu_assert(mbuf);

        memset(rx_bd, 0, sizeof(*rx_bd));

        gemu_log("rx_bd %p mbuf %p phys_data_buf_addr %p\n", 
            (void *)rx_bd, (void *)mbuf, (void *)rte_pktmbuf_iova(mbuf));
        gemu_bd_set_addr_rx(rx_bd, rte_pktmbuf_iova(mbuf)); 
       
        // upper16 bit buf_pool_id (gemu device_id)
        // lower16 bit bd_id (index i)
        // u32 hbd_data = (gemu->config.device_id << 16) | i;
        // gemu_bd_set_hbd_data(rx_bd, hbd_data);
        gemu_desc *desc = (gemu_desc *) rx_bd;
        desc->bd.bd_id = i;
        gemu_log("rx_bd w0=0x%x w1=0x%x w2=0x%x w3=0x%x\n", (*rx_bd)[0], (*rx_bd)[1], (*rx_bd)[2], (*rx_bd)[3]);

        UINTPTR pktmbuf_phys_addr = gemu_bd_get_rx_buf_addr(rx_bd);
        gemu_assert(pktmbuf_phys_addr ==  rte_pktmbuf_iova(mbuf));

        if (i == rx_q->rx_bd_count-1)
        {
            gemu_desc *rx_desc = (gemu_desc *)rx_bd;
            u32 w0 = rx_desc->bd.addr_lo | GEM_RXBUF_WRAP_MASK;
            rx_desc->bd.addr_lo = w0;
        }
        
        gemu_hbd *rx_hbd = rx_q->rx_hbds+i;
        memset(rx_hbd, 0, sizeof(*rx_hbd));

        rx_hbd->desc = (gemu_desc *)rx_bd;
        rx_hbd->phys_desc = phys_rx_bd;
        rx_hbd->buf = (UINTPTR)mbuf;
        rx_hbd->bd_id = i;
        rx_hbd->type = GEMU_HBD_RX;
        rx_hbd->pktmbuf_phys_addr = pktmbuf_phys_addr;
        mbuf->refcnt++; // set to 0 on free;

        rx_bd++;
        phys_rx_bd += sizeof(*rx_bd);
    }
}

static void gemu_init_tx_bds(gemu *gemu, gemu_tx_q *tx_q)
{
    gemu_bd *tx_bd = (gemu_bd *)tx_q->tx_bd_mem;
    UINTPTR phys_tx_bd = tx_q->phys_tx_bd_mem;

    tx_q->tx_pi = 0;
    tx_q->tx_ci = 0;

    tx_q->tx_prev_ci = 0;

    gemu_assert(tx_bd);
    gemu_log("GEM %s tx_q %d setting up tx bds\n", gemu->config.name, tx_q->tx_q_id);

    memset(tx_q->tx_hbds, 0, sizeof(tx_q->tx_hbds));

    u32 i;
    for (i=0; i < tx_q->tx_bd_count; i++)
    {
        memset(tx_bd, 0, sizeof(*tx_bd));
        gemu_desc *tx_desc = (gemu_desc *)tx_bd;
        tx_desc->bd.status = GEM_TXBUF_USED_MASK;
        tx_desc->bd.bd_id = i;
        if (i == tx_q->tx_bd_count-1)
        {
            gemu_desc *tx_desc = (gemu_desc *)tx_bd;
            u32 w1 = tx_desc->bd.status | GEM_TXBUF_WRAP_MASK;
            tx_desc->bd.status = w1;
        }

        u32 hbd_data = i;
        gemu_bd_set_hbd_data(tx_bd, hbd_data);

        gemu_hbd *tx_hbd = tx_q->tx_hbds+i;

        tx_hbd->desc = (gemu_desc *)tx_bd;
        tx_hbd->phys_desc = phys_tx_bd; 
        tx_hbd->bd_id = i;
        tx_hbd->type = GEMU_HBD_TX;

        tx_bd++;
        phys_tx_bd += sizeof(*tx_bd);

        gemu_log("tx_bd w0=0x%x w1=0x%x w2=0x%x w3=0x%x\n", (*tx_bd)[0], (*tx_bd)[1], (*tx_bd)[2], (*tx_bd)[3]);
    }
}

#ifdef GEMU_TESTAPP
// configure per port/device rx_bd_count, tx_bd_count
// per rx-q, tx-q todo FIXME PK
// allocate rx_bd descs memory and rx-bufs memory, initialize rx_q
static LONG gemu_rx_q_setup(gemu *gemu, int rx_q_id) 
{
    gemu_config *config = &gemu->config;

    gemu_assert (config->base_addr);

    assert(rx_q_id <GEM_MAX_RX_QUEUES);

    gemu_rx_q *rx_q = &gemu->rx_queues[rx_q_id];

    rx_q->rx_q_id = rx_q_id;
    rx_q->gemu = gemu;

    gemu_assert (!rx_q->rx_bd_mem);

    rx_q->rx_bd_count = gemu->config.rx_bd_count;
    rx_q->rx_bd_memsize = rx_q->rx_bd_count * sizeof (gemu_bd);

    gemu_desc *rx_bd_mem; 
    rx_bd_mem = (gemu_desc *)rte_mempool_alloc_bdmem(rx_q->rx_bd_memsize); 
    assert(rx_bd_mem);

    rx_q->phys_rx_bd_mem = rte_mem_virt2phy(rx_bd_mem); 
    assert(rx_q->phys_rx_bd_mem != RTE_BAD_IOVA);

    rx_q->rx_bd_mem = rx_bd_mem;
    gemu_log("GEM %s tx_q %d\n", gemu->config.name, rx_q_id);
    gemu_log("BD mem allocated, rx_bd_count %d rx_bd_memsz %d, rx_bd_mem %p phys_rx_bd_mem %p\n", 
        rx_q->rx_bd_count, rx_q->rx_bd_memsize,  rx_q->rx_bd_mem, (void *)rx_q->phys_rx_bd_mem);

    // allocate buffers
    struct rte_mempool *mp = &rx_q->mp;
    rte_mempool_alloc_bufmem(gemu, mp, rx_q->rx_bd_count);
    mp->rx_q = rx_q;

    gemu_assert(mp->bufmem_start);
    gemu_assert(mp->bufmem_end);

    gemu_init_rx_bds(gemu, rx_q);

    return GEMU_SUCCESS;
}

static LONG gemu_tx_q_setup(gemu *gemu, int tx_q_id) 
{
    gemu_config *config = &gemu->config;

    gemu_assert (config->base_addr);
    assert(tx_q_id <GEM_MAX_TX_QUEUES);

    gemu_tx_q *tx_q = &gemu->tx_queues[tx_q_id];
    tx_q->tx_q_id = tx_q_id;
    tx_q->gemu = gemu;

    gemu_assert (!tx_q->tx_bd_mem);

    tx_q->tx_bd_count = gemu->config.tx_bd_count;
    tx_q->tx_bd_memsize = tx_q->tx_bd_count * sizeof (gemu_bd);

    gemu_desc *tx_bd_mem; 
    tx_bd_mem = (gemu_desc *)rte_mempool_alloc_bdmem(tx_q->tx_bd_memsize); 
    assert(tx_bd_mem);

    tx_q->phys_tx_bd_mem = rte_mem_virt2phy(tx_bd_mem); 
    assert(tx_q->phys_tx_bd_mem != RTE_BAD_IOVA);

    tx_q->tx_bd_mem = tx_bd_mem;
    gemu_log("GEM %s tx_q %d\n", gemu->config.name, tx_q_id);
    gemu_log("BD mem allocated, tx_bd_count %d tx_bd_memsz %d, tx_bd_mem %p phys_tx_bd_mem %p\n", 
        tx_q->tx_bd_count, tx_q->tx_bd_memsize,  tx_q->tx_bd_mem, (void *)tx_q->phys_tx_bd_mem);

    gemu_init_tx_bds(gemu, tx_q);

    return GEMU_SUCCESS;
}

static void gemu_dev_configure(gemu *gemu, int device_id, UINTPTR base_virt_addr)
{
    gemu_config *config;

    if (!gemu->config.base_addr)
    {
        gemu_assert(base_virt_addr);
        config = gemu_lookup_config(device_id);
        memcpy(&gemu->config, config, sizeof(gemu->config));
        gemu->config.base_addr = base_virt_addr;
    }

    // gemu_read_desc(gemu);
    // exit(0);

    // start from clean state
    // gemu_hw_reset(gemu); PK FIXME

    gemu_disable(gemu);

    gemu->num_rx_queues = 1;
    gemu->num_tx_queues = 2;
    for (int i=0; i < gemu->num_rx_queues; i++)
    {
        gemu_rx_q_setup(gemu, i);
    }

    for (int i=0; i < gemu->num_tx_queues; i++)
    {
        gemu_tx_q_setup(gemu, i);
    }

    gemu_configure_queue_ptrs(gemu);
}

static void gemu_dev_shutdown(gemu *gemu)
{
    //gemu_hw_stop(gemu);
    //

    if (gemu->started)
    {
        gemu_disable(gemu);
    }

    for (int i=0; i < GEM_MAX_TX_QUEUES; i++)
    {
        gemu_tx_q *tx_q = &gemu->tx_queues[i];
        rte_mempool_free_bdmem((void *)tx_q->tx_bd_mem, tx_q->tx_bd_memsize);
    }

    for (int i=0; i < GEM_MAX_RX_QUEUES; i++)
    {
        gemu_rx_q *rx_q = &gemu->rx_queues[i];
        rte_mempool_free_bdmem((void *)rx_q->rx_bd_mem, rx_q->rx_bd_memsize);
        rte_mempool_free_bufmem(&rx_q->mp);
    }
}
#else
static void gemu_dev_shutdown(gemu *gemu)
{
    //gemu_hw_stop(gemu);
    //

    if (gemu->started)
    {
        gemu_disable(gemu);
    }
}
#endif

static ALWAYS_INLINE void  gemu_refill_rx_bufs(gemu *gemu)
{
    gemu = gemu;
}

static ALWAYS_INLINE void gemu_dump_app_stats(gemu *gemu)
{
    //printf("\t tx_added         %d\n", gemu->stats.tx_added);
    //printf("\t tx_pkts          %d\n", gemu->stats.tx_pkts);
    //printf("\t tx_start         %d\n", gemu->stats.tx_start);
    //printf("\t tx_queueue_ful   %d\n", gemu->stats.tx_queue_full);
    printf("\t rx_ip_pkts       %d\n", gemu->stats.rx_ip_pkts);
    printf("\t rx_nonip_pkts    %d\n", gemu->stats.rx_nonip_pkts);
    printf("\t rx_bufs_freed    %d\n", gemu->stats.rx_bufs_freed);
    printf("\t tcp_pkts_rxed    %d\n", gemu->stats.tcp_pkts_rxed);
    printf("\t udp_pkts_rxed    %d\n", gemu->stats.udp_pkts_rxed);
    printf("\t icmp_pkts_rxed   %d\n", gemu->stats.icmp_pkts_rxed);

    printf("\t icmp_echo_reqs   %d\n", gemu->stats.icmp_echo_requests);
    printf("\t icmp_echo_repl   %d\n", gemu->stats.icmp_echo_replies);

    printf("\t tcp_pkts_fwded   %d\n", gemu->stats.tcp_pkts_fwded);
    printf("\t udp_pkts_fwded   %d\n", gemu->stats.udp_pkts_fwded);
    printf("\t icmp_echo_req_fwded    %d\n", gemu->stats.icmp_echo_req_fwded);
    printf("\t icmp_echo_reply_fwded  %d\n", gemu->stats.icmp_echo_reply_fwded);

    printf("\t rx_pkts_tossed   %d\n", gemu->stats.rx_pkts_tossed);

}

static ALWAYS_INLINE void gemu_set_affinity(int cpuid)
{
    pthread_t thread;
    cpu_set_t cpuset;
    int s;

    thread = pthread_self();

    // Zero out the cpuset
    CPU_ZERO(&cpuset);

    // Add CPU "cpuid" to the cpuset
    CPU_SET(cpuid, &cpuset);

    // Set the affinity of the thread to the cpuset
    s = pthread_setaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
    if (s != 0) {
        perror("pthread_setaffinity_np");
        exit(EXIT_FAILURE);
    }

    // Verify the affinity mask
    s = pthread_getaffinity_np(thread, sizeof(cpu_set_t), &cpuset);
    if (s != 0) {
        perror("pthread_getaffinity_np");
        exit(EXIT_FAILURE);
    }

    printf("Thread %ld is running on CPU(s): ", (long)thread);
    for (int j = 0; j < CPU_SETSIZE; j++) {
        if (CPU_ISSET(j, &cpuset)) {
            printf("%d ", j);
        }
    }
}

static ALWAYS_INLINE void gemu_main_init(gemu_main *gm)
{
    gm->memfd = open("/dev/mem", O_RDWR | O_SYNC);
    if (gm->memfd == -1) 
    {
        gemu_err("Can't open /dev/mem. %s\n", strerror(errno));
        exit(0);
    }

    gemu_log("/dev/mem opened.\n"); 
    gm->_pagesize = getpagesize();
}

static ALWAYS_INLINE void gemu_main_shutdown(gemu_main *gm)
{
   assert(gm);
   close(gm->memfd);
    // shutdown all active gemu instances
}

static ALWAYS_INLINE void gemu_dev_init(gemu *gemu, unsigned int gem_id)
{
    gemu_main *gm = gemu->gm;
    gemu_config *config = &gemu->config;

    memset(config, 0, sizeof(gemu->config));
    config->device_id = gem_id;
    assert(config->device_id < GEM_MAX_DEVICES);

    assert(!config->base_addr);

    volatile void *gem_mapped_base, *gem_base_addr; 
    off_t gem_dev_base = 0; 

    // for now supporting only GEM 0,1
    if (config->device_id == 0)
        gem_dev_base = ZYNQMP_GEM_0_BASEADDR; 
    if (config->device_id == 1)
        gem_dev_base = ZYNQMP_GEM_1_BASEADDR; 
    assert(gem_dev_base);

    gem_mapped_base = mmap(0, GEM_DEV_MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, gm->memfd, 
                            gem_dev_base & ~(off_t)(gm->_pagesize - 1));
    if (gem_mapped_base == (void *) -1) 
    {
        gemu_err("Can't map the GEM0 memory IO regs to user space. %s\n", strerror(errno));
        exit(0);
    }
    gem_base_addr = (void *)((u64)gem_mapped_base + (gem_dev_base & GEM_DEV_MAP_MASK));
    gemu_log("GEM%d base addr %p \n", config->device_id, gem_base_addr); 

    config->base_addr = (UINTPTR)gem_base_addr;
}

#if 0
static ALWAYS_INLINE void gemu_dev_configure(gemu *gemu, u16 gem_id, u16 num_rx_queues, u16 num_tx_queues)
{
    assert(gem_id < 2);
}
#endif

#ifdef GEMU_TESTAPP
static ALWAYS_INLINE void gemu_init(gemu_main *gm, int gem_id)
{
    assert(gem_id < GEM_MAX_DEVICES);

    volatile void *gem_mapped_base, *gem_base_addr; 
    off_t gem_dev_base = 0; 

    if (gem_id == 0)
        gem_dev_base = ZYNQMP_GEM_0_BASEADDR; 
    if (gem_id == 1)
        gem_dev_base = ZYNQMP_GEM_1_BASEADDR; 
    assert(gem_dev_base);
    
    gemu *gemu= &gm->gemu_dev_list[gem_id];
    gemu->gm = gm;

    gem_mapped_base = mmap(0, GEM_DEV_MAP_SIZE, PROT_READ | PROT_WRITE, MAP_SHARED, gm->memfd, 
                            gem_dev_base & ~(off_t)(gm->_pagesize - 1));
    if (gem_mapped_base == (void *) -1) 
    {
        gemu_err("Can't map the GEM0 memory IO regs to user space. %s\n", strerror(errno));
        exit(0);
    }

    gem_base_addr = (void *)((u64)gem_mapped_base + (gem_dev_base & GEM_DEV_MAP_MASK));
    gemu_log("GEM%d base addr %p \n", gem_id, gem_base_addr); 
    gemu_dev_configure(gemu, gem_id, (UINTPTR)gem_base_addr);
    gemu_clear_error(gemu);
    gemu_enable(gemu);
    gemu_dump_desc(gemu);
    //
}
#endif

#endif // __GEMU_GEMIO_H__ 
