#ifndef __GEMU_LOG_H__
#define __GEMU_LOG_H__

#include <stdarg.h>

#ifndef GEMU_TESTAPP
#include <inttypes.h>
#include <rte_log.h>

/* system camel case definition changed to upper case */
#define PRIU32 PRIu32
#define PRIU64 PRIu64

/* Format specifiers for string data pairs */
#define GEMU_SU32  "\n\t%-20s    %'20" PRIU32
#define GEMU_SU64  "\n\t%-20s    %'20" PRIU64
#define GEMU_SU64X "\n\t%-20s    %#20" PRIx64
#define GEMU_SPTR  "\n\t%-20s    %20p"

extern int gemu_logtype;

#define GEMU_PMD_LOG(level, fmt, args...)        \
        rte_log(RTE_LOG_ ##level, gemu_logtype, "GEMU: " fmt, ## args)


/* Debug macro to enable core debug code */
#ifdef RTE_LIBRTE_ETHDEV_DEBUG
#define GEMU_DEBUG_CORE 1
#else
#define GEMU_DEBUG_CORE 0
#endif

#define gemu_log(fmt, args...) \
	GEMU_PMD_LOG(DEBUG, fmt, ## args)

#define gemu_err(fmt, args...) \
	GEMU_PMD_LOG(ERR, fmt, ## args)

#define gemu_mm_err(fmt, args...) \
	GEMU_PMD_LOG(ERR, fmt, ## args)

#define gemu_mm_log(fmt, args...) \
	GEMU_PMD_LOG(DEBUG, fmt, ## args)

#else

typedef enum {
	GEMU_LOG_DEBUG = 0,
	GEMU_LOG_WARN,
	GEMU_LOG_ERR
} gemu_log_type;

#define GEMU_PMD_LOG(level, fmt, args...)        \
	gemu_rte_log(GEMU_LOG_##level, fmt, ##  args) 
	
#define gemu_log(fmt, args...) \
	GEMU_PMD_LOG(DEBUG, fmt, ## args)

static inline void gemu_rte_log(gemu_log_type type, const char *fmt, ...)
{
#if 0
  // add type TODO FIXME
  printf("GEMU log%d : ", type);
  va_list ap;
  va_start(ap, fmt);
  vprintf(fmt, ap);
  va_end(ap);
#endif
}

#define gemu_err(fmt, args...) \
	GEMU_PMD_LOG(ERR, fmt, ## args)

#define gemu_mm_err(fmt, args...) \
	GEMU_PMD_LOG(ERR, fmt, ## args)

#define gemu_mm_log(fmt, args...) 

#if 0
#define gemu_mm_log(fmt, args...) \
	GEMU_PMD_LOG(DEBUG, fmt, ## args)
#endif


#endif // GEMU_TESTAPP
       
#endif // __GEMU_LOG_H__
