#ifndef __GEMU_TYPES_H__
#define __GEMU_TYPES_H__

typedef unsigned char u8;
typedef uint16_t      u16;
typedef uint32_t      u32;
typedef uint64_t      u64;
typedef long          LONG;
typedef unsigned long ULONG;
typedef uint64_t      UINTPTR;
typedef int64_t       INTPTR;
typedef int32_t          s32;

#define CLIB_LOG2_CACHE_LINE_BYTES   6
#define CLIB_CACHE_LINE_BYTES   (1 << CLIB_LOG2_CACHE_LINE_BYTES)
#define CLIB_CACHE_LINE_ALIGN_MARK(mark)   u8 mark[0] __attribute__((aligned(CLIB_CACHE_LINE_BYTES)))
#define CLIB_N_PREFETCHES   16
#define CLIB_PREFETCH_READ   0
#define CLIB_PREFETCH_LOAD   0 /* alias for read */
#define CLIB_PREFETCH_WRITE   1
#define CLIB_PREFETCH_STORE   1 /* alias for write */
#define CLIB_PREFETCH(addr, size, type)

#define MAC_ADDR_LEN  6
typedef u8            MAC_ADDR[MAC_ADDR_LEN];

#define ULONG64_HI_MASK    0xFFFFFFFF00000000U
#define ULONG64_LO_MASK    ~ULONG64_HI_MASK

#ifndef SIZE_ASSERT
#define SIZE_ASSERT( what, howmuch ) \
  typedef char what##_size_wrong_[( !!(sizeof(what) == howmuch) )*2-1 ]
#endif

#define ALWAYS_INLINE inline __attribute__((always_inline))

#define likely(x)   __builtin_expect(!!(x), 1)
#define unlikely(x) __builtin_expect(!!(x), 0)

#define gemu_assert(cond)  assert(cond)

#if 0
#ifdef GEMU_DEBUG
#define gemu_assert(cond)  assert(cond)
#else
#define gemu_assert(cond)
#endif
#endif

#endif // __GEMU_TYPES_H
