#ifndef __GEMU_DEVICE_H__
#define __GEMU_DEVICE_H__

static ALWAYS_INLINE u32 gemu_get_qx_offset(gemu_qx_reg_offset reg, u8 queue)
{
    u32 map[GEM_REG_END][GEM_MAX_QUEUES] = {
        { GEM_TXQBASE_OFFSET, GEM_TXQ1BASE_OFFSET }, /* TXQIBASE */
        { GEM_RXQBASE_OFFSET, GEM_RXQ1BASE_OFFSET }, /* RXQIBASE  */
        { 0, GEM_DMA_RXQ1_BUFSIZE_OFFSET }, /* DMA_RXQI_BUFSIZE */
        { GEM_ISR_OFFSET, GEM_INTQ1_STS_OFFSET }, /* INTQI_STS */
        { 0, GEM_INTQ1_IER_OFFSET },  /* INTQI_IER */
        { 0, GEM_INTQ1_IDR_OFFSET }}; /* INTQI_IDR */

    assert(reg < GEM_REG_END);
    assert(queue < GEM_MAX_QUEUES);

    return map[reg][queue];
}

static ALWAYS_INLINE void gemu_dump_stats(gemu *gemu)
{
    printf("GEMU device id %d\n", gemu->config.device_id);

    u32 val = gemu_read_reg(gemu->config.base_addr, GEM_TXCNT_OFFSET);
    printf("Total Packets sent: %d\n", val);

    val = gemu_read_reg(gemu->config.base_addr, GEM_RXCNT_OFFSET);
    printf("Total Packets received: %d\n", val);
}

static ALWAYS_INLINE void gemu_err_handler(gemu *gemu)
{
    u32 reg_isr;
    u32 reg_sr;
    u32 reg_ctrl;
    u32 reg_qi_isr[32] = {0};        /* Max queues possible */
    u8 i = 0;

    reg_isr = gemu_read_reg(gemu->config.base_addr, GEM_ISR_OFFSET);

    for (i=0; i < gemu->max_queues; i++)
    {
        reg_qi_isr[i] = gemu_read_reg(gemu->config.base_addr, gemu_get_qx_offset(INTQI_STS, i));
    }

    gemu_write_reg(gemu->config.base_addr, GEM_ISR_OFFSET, reg_qi_isr[0]);

    for(i=0; i < gemu->max_queues;  i++)
    {
        if ( reg_qi_isr[i]  & GEM_INTQISR_RXCOMPL_MASK ) 
        {
            gemu_assert(!"GEM_INTQISR_RXCOMPL_MASK should be disabled!!!!");

        }

    }
    for(i=0; i < gemu->max_queues;  i++)
    {
        if ( reg_qi_isr[i]  & GEM_INTQISR_TXCOMPL_MASK ) {
            gemu_assert(!"GEM_INTQISR_RXCOMPL_MASK should be disabled!!!!");

        }
    }

    if ((reg_isr & GEM_IXR_RX_ERR_MASK) != 0x00000000U) 
    {
        reg_sr = gemu_read_reg(gemu->config.base_addr, GEM_RXSR_OFFSET);
        gemu_write_reg(gemu->config.base_addr, GEM_RXSR_OFFSET, reg_sr);

        /* Fix for CR # 692702. Write to bit 18 of net_ctrl
         * register to flush a packet out of Rx SRAM upon
         * an error for receive buffer not available. */
        if ((reg_isr & GEM_IXR_RXUSED_MASK) != 0x00000000U) 
        {
            reg_ctrl = gemu_read_reg(gemu->config.base_addr, GEM_NWCTRL_OFFSET);
            reg_ctrl |= (u32)GEM_NWCTRL_FLUSH_DPRAM_MASK;
            gemu_write_reg(gemu->config.base_addr, GEM_NWCTRL_OFFSET, reg_ctrl);
        }

    }

    /* When GEM_IXR_TXCOMPL_MASK is flagged, GEM_IXR_TXUSED_MASK
    * will be gemu_asserted the same time.
    * Have to distinguish this bit to handle the real error condition.
    */
    /* Transmit Q1,2,.. error conditions interrupt */
    for(i=1; i < gemu->max_queues;  i++)
    {
        if(((reg_qi_isr[i] & GEM_INTQSR_TXERR_MASK) != 0x00000000U) &&
           ((reg_qi_isr[i] & GEM_INTQISR_TXCOMPL_MASK) != 0x00000000U)) 
        {
            /* Clear Interrupt Q1 status register */
            gemu_write_reg(gemu->config.base_addr, gemu_get_qx_offset(INTQI_STS, i), reg_qi_isr[i]); 
        }
    }

    /* Transmit error conditions interrupt */
    if (((reg_isr & GEM_IXR_TX_ERR_MASK) != 0x00000000U) &&
        ((!(reg_isr & GEM_IXR_TXCOMPL_MASK)) != 0x00000000U)) 
    {
        reg_sr = gemu_read_reg(gemu->config.base_addr, GEM_TXSR_OFFSET);
        gemu_write_reg(gemu->config.base_addr, GEM_TXSR_OFFSET, reg_sr);
    }

}

static ALWAYS_INLINE void gemu_handle_error(gemu *gemu)
{
    u32 val = gemu_read_reg(gemu->config.base_addr, GEM_ISR_OFFSET);

    if ((val & GEM_IXR_TX_ERR_MASK) || (val & GEM_IXR_RX_ERR_MASK))
    {
#ifdef GEMU_DEBUG
        gemu_log("GEM device %d error ISR     : 0x%0x\n", gemu->config.device_id, val);
        gemu_err_handler(gemu);
#endif
    }
}

static ALWAYS_INLINE void gemu_enable(gemu *gemu)
{
    gemu_log("Enabling %s\n", gemu->config.name);
    gemu_assert(!gemu->started);

    gemu_write_reg(gemu->config.base_addr, GEM_NWCFG_OFFSET, 0x012E0452);

    gemu_write_reg(gemu->config.base_addr, GEM_DMACR_OFFSET, 0x40180F10); 

    gemu_write_reg(gemu->config.base_addr, GEM_ISR_OFFSET, GEM_IXR_ALL_MASK);

    gemu_write_reg(gemu->config.base_addr, GEM_NWCTRL_OFFSET, (GEM_NWCTRL_RXEN_MASK | GEM_NWCTRL_TXEN_MASK));
    gemu->started = 1;

    gemu_log("Wait 5 sec..\n");
    sleep(5);
    gemu_log("Enabling %s complete\n", gemu->config.name);
}

static ALWAYS_INLINE void gemu_disable(gemu *gemu)
{
    gemu_log("Disabling %s\n", gemu->config.name);
    gemu_write_reg(gemu->config.base_addr, GEM_IDR_OFFSET, GEM_IXR_ALL_MASK);
    gemu_write_reg(gemu->config.base_addr, GEM_ISR_OFFSET, GEM_IXR_ALL_MASK);
    gemu_write_reg(gemu->config.base_addr, GEM_NWCTRL_OFFSET, 0);
    gemu->started = 0;

    gemu_log("Wait 5 sec..\n");
    sleep(5);
    gemu_log("Disabling %s complete\n", gemu->config.name);
}

static ALWAYS_INLINE int gemu_tx_status(gemu *gemu)
{
    u32 tx_status = gemu_read_reg(gemu->config.base_addr, GEM_TXSR_OFFSET); 

    // TX-Q-0
    gemu_tx_q *tx_q = &gemu->tx_queues[0];
    
    if (tx_status)
    {
        gemu_log("!!!!!!!!TX status 0x%0x\n", tx_status);
    }
 
    if (tx_status & GEM_TXSR_TXGO_MASK)
    {
        tx_q->tx_stats.tx_status_go++;
        return 1;
    }

    if (tx_status & GEM_TXSR_TXCOMPL_MASK)
    {
        gemu_log("!!!!!!!!TX complete 0x%0x\n", tx_status);
        gemu_write_reg(gemu->config.base_addr, GEM_TXSR_OFFSET, tx_status);
        tx_q->tx_stats.tx_status_complete++;
        return 0;
    }

    if (tx_status & GEM_TXSR_ERROR_MASK)
    {
        gemu_log("!!!!!!!!TX error 0x%0x\n", tx_status);
        tx_q->tx_stats.tx_status_err++;

        //gemu_assert(!"!!!!!!!!TX error");
    }

    return 1;
}

static ALWAYS_INLINE void gemu_rx_status(gemu_rx_q *rx_q)
{
    gemu *gemu = rx_q->gemu;

    u32 rx_status = gemu_read_reg(gemu->config.base_addr, GEM_RXSR_OFFSET);
    if (rx_status & GEM_RXSR_FRAMERX_MASK)
    {
        // clear rx-status 
        gemu_write_reg(gemu->config.base_addr, GEM_RXSR_OFFSET, rx_status);
    }
}

static ALWAYS_INLINE void gemu_clear_error(gemu *gemu)
{
    // rte_rmb(); do we need this?

    u32 rx_status = gemu_read_reg(gemu->config.base_addr, GEM_RXSR_OFFSET);
    u32 tx_status = gemu_read_reg(gemu->config.base_addr, GEM_TXSR_OFFSET);

    if (rx_status & GEM_RXSR_ERROR_MASK)
    {
        gemu_write_reg(gemu->config.base_addr, GEM_RXSR_OFFSET, rx_status);
    }

    if (tx_status & GEM_TXSR_ERROR_MASK)
    {
        gemu_write_reg(gemu->config.base_addr, GEM_TXSR_OFFSET, tx_status);
    }
}


// device should be disabled(tx/rx disable) before setting mac address 
static ALWAYS_INLINE int gemu_set_mac_addr(gemu *instance, MAC_ADDR mac_addr, u8 index)
{
    u32 mac_addr_32;
    void *gem_base_addr = (void *)instance->config.base_addr;

    /* Set the MAC bits [31:0] in BOT */
    mac_addr_32 = mac_addr[0];
    mac_addr_32 |= ((u32)(mac_addr[1]) << 8U);
    mac_addr_32 |= ((u32)(mac_addr[2]) << 16U);
    mac_addr_32 |= ((u32)(mac_addr[3]) << 24U);
    gemu_write_reg(gem_base_addr, ((u32)GEM_LADDR1L_OFFSET + ((u32)index * (u32)8)), mac_addr_32);

    /* There are reserved bits in TOP so don't affect them */
    mac_addr_32 = gemu_read_reg(gem_base_addr, ((u32)GEM_LADDR1H_OFFSET + ((u32)index * (u32)8)));

    mac_addr_32 &= (u32)(~GEM_LADDR_MACH_MASK);

    /* Set MAC bits [47:32] in TOP */
    mac_addr_32 |= (u32)(mac_addr[4]);
    mac_addr_32 |= (u32)(mac_addr[5] << 8U);

    gemu_write_reg(gem_base_addr, ((u32)GEM_LADDR1H_OFFSET + ((u32)index * (u32)8)), mac_addr_32);

    return 0;
}

static ALWAYS_INLINE void gemu_get_mac_addr(gemu *instance, MAC_ADDR mac_addr, u8 index)
{
    u32 mac_addr_32;
    void *gem_base_addr = (void *)instance->config.base_addr;

    mac_addr_32 = gemu_read_reg(gem_base_addr, ((u32)GEM_LADDR1L_OFFSET + ((u32)index * (u32)8)));
    mac_addr[0] = (u8) mac_addr_32;
    mac_addr[1] = (u8) (mac_addr_32 >> 8U);
    mac_addr[2] = (u8) (mac_addr_32 >> 16U);
    mac_addr[3] = (u8) (mac_addr_32 >> 24U);

    /* Read MAC bits [47:32] in TOP */
    mac_addr_32 = gemu_read_reg(gem_base_addr, ((u32)GEM_LADDR1H_OFFSET + ((u32)index * (u32)8)));
    mac_addr[4] = (u8) mac_addr_32;
    mac_addr[5] = (u8) (mac_addr_32 >> 8U);
}

static ALWAYS_INLINE void gemu_hw_reset_x(gemu *instance) 
{
    void *base_addr = (void *)instance->config.base_addr; 
    u32 regval;

    /* Disable the interrupts  */
    gemu_write_reg(base_addr,GEM_IDR_OFFSET,0x0U);

    /* Stop transmission,disable loopback and Stop tx and Rx engines */
    regval = gemu_read_reg(base_addr,GEM_NWCTRL_OFFSET);
    regval &= ~((u32)GEM_NWCTRL_TXEN_MASK|
                (u32)GEM_NWCTRL_RXEN_MASK|
                (u32)GEM_NWCTRL_HALTTX_MASK|
                (u32)GEM_NWCTRL_LOOPEN_MASK);
    /* Clear the statistic registers, flush the packets in DPRAM*/
    regval |= (GEM_NWCTRL_STATCLR_MASK|
                GEM_NWCTRL_FLUSH_DPRAM_MASK);
    gemu_write_reg(base_addr,GEM_NWCTRL_OFFSET,regval);
    /* Clear the interrupt status */
    gemu_write_reg(base_addr,GEM_ISR_OFFSET,GEM_IXR_ALL_MASK);
    /* Clear the tx status */
    gemu_write_reg(base_addr,GEM_TXSR_OFFSET,(GEM_TXSR_ERROR_MASK|
                          (u32)GEM_TXSR_TXCOMPL_MASK|
                        (u32)GEM_TXSR_TXGO_MASK));
    /* Clear the rx status */
    gemu_write_reg(base_addr,GEM_RXSR_OFFSET, GEM_RXSR_FRAMERX_MASK);
    /* Clear the tx base addr */
    gemu_write_reg(base_addr,GEM_TXQBASE_OFFSET,0x0U);
    /* Clear the rx base addr */
    gemu_write_reg(base_addr,GEM_RXQBASE_OFFSET,0x0U);
    /* Update the network config register with reset value */
    gemu_write_reg(base_addr,GEM_NWCFG_OFFSET,GEM_NWCFG_RESET_MASK);
    /* Update the hash addr registers with reset value */
    gemu_write_reg(base_addr,GEM_HASHL_OFFSET,0x0U);
    gemu_write_reg(base_addr,GEM_HASHH_OFFSET,0x0U);
}

#endif // __GEMU_DEVICE_H__
