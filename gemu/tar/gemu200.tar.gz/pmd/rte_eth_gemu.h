/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2014 Intel Corporation
 */

#ifndef _RTE_ETH_GEMU_H_
#define _RTE_ETH_GEMU_H_

#define GEMU_MAX_RX_PKTLEN  9728U 
#define GEMU_BUF_SIZE_MIN   256
#define GEMU_FRAME_SIZE_MAX 9728

#define GEMU_ETH_OVERHEAD \
        (RTE_ETHER_HDR_LEN + RTE_ETHER_CRC_LEN + RTE_VLAN_HLEN * 2)
#define GEMU_ETH_MAX_LEN (RTE_ETHER_MTU + GEMU_ETH_OVERHEAD)

#define GEMU_DEFAULT_RX_FREE_THRESH  32
#define GEMU_DEFAULT_RX_PTHRESH      8
#define GEMU_DEFAULT_RX_HTHRESH      8
#define GEMU_DEFAULT_RX_WTHRESH      0

#define GEMU_DEFAULT_TX_FREE_THRESH  32
#define GEMU_DEFAULT_TX_PTHRESH      32
#define GEMU_DEFAULT_TX_HTHRESH      0
#define GEMU_DEFAULT_TX_WTHRESH      0
#define GEMU_DEFAULT_TX_RSBIT_THRESH 32

#define GEMU_NUM_DESC_DEFAULT     512
#define GEMU_NUM_DESC_ALIGN       32

#define GEMU_MIN_RING_DESC      64
#define GEMU_MAX_RING_DESC      8160
#define GEMU_ALIGN_RING_DESC    32

#define GEMU_TX_MAX_SEG     UINT8_MAX
#define GEMU_TX_MAX_MTU_SEG 8

typedef struct rte_eth_gemu
{
    struct rte_vdev_device *vdev;
    struct rte_eth_dev *eth_dev;
    struct gemu *gemu;
} rte_eth_gemu;

#define RTE_DEV_GET_GEMU(dev) \
    struct rte_eth_gemu *gemu_pmd = (rte_eth_gemu *)(dev->data->dev_private); \
    gemu *gemu = gemu_pmd->gemu; \
    assert(gemu); \
    assert(gemu->app_data == gemu_pmd);\


#ifdef __cplusplus
extern "C" {
#endif

#ifdef __cplusplus
}
#endif

#endif
