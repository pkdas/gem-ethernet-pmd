/* SPDX-License-Identifier: BSD-3-Clause
 * Copyright(c) 2010-2015 Intel Corporation
 */

#include <stdlib.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <sys/un.h>
#include <sys/ioctl.h>
#include <sys/mman.h>
#include <linux/if_ether.h>
#include <errno.h>
#include <sys/eventfd.h>

#include <rte_version.h>
#include <rte_mbuf.h>
#include <rte_ether.h>
#include <ethdev_driver.h>
#include <ethdev_vdev.h>
#include <rte_malloc.h>
#include <rte_kvargs.h>
#include <bus_vdev_driver.h>
#include <rte_string_fns.h>
#include <rte_errno.h>
#include <rte_memory.h>
#include <rte_memzone.h>
#include <rte_eal_memconfig.h>
#include <rte_atomic.h>

#include "gemu_log.h"
#include "gemu_types.h"
#include "gemu_ext.h"
#include "gemu_gemio.h"

#include "rte_eth_gemu.h"

#define ETH_GEM_ID_PARAM    "id"

static const char *valid_arguments[] = {
    ETH_GEM_ID_PARAM,
    NULL
};

#define PMD_LOG(level, ...) \
    RTE_LOG_LINE_PREFIX(level, ETH_GEMU, "%s(): ", __func__, __VA_ARGS__)

RTE_LOG_REGISTER_DEFAULT(gemu_logtype, NOTICE);
#define RTE_LOGTYPE_ETH_GEMU gemu_logtype

static struct gemu_main *gm = NULL;

static uint16_t
eth_dev_rx_pkts(void *rx_q, struct rte_mbuf **bufs, uint16_t nb_bufs)
{
    u16 rx_count = gemu_rx_burst((gemu_rx_q *)rx_q, bufs, nb_bufs);
    return rx_count;
}

static uint16_t
eth_dev_tx_pkts(void *tx_q, struct rte_mbuf **bufs, uint16_t nb_bufs)
{
    u16 tx_count = gemu_tx_burst((gemu_tx_q *)tx_q, bufs, nb_bufs);
    return tx_count;
}

static int
eth_dev_configure(struct rte_eth_dev *dev) 
{ 
    RTE_DEV_GET_GEMU(dev);

    assert(!gemu->started);

    assert(dev->data->dev_conf.link_speeds == 0);
    assert(dev->data->dev_conf.rxmode.offloads & RTE_ETH_RX_OFFLOAD_IPV4_CKSUM);
    assert(dev->data->dev_conf.rxmode.offloads & RTE_ETH_RX_OFFLOAD_CHECKSUM);

    assert(dev->data->dev_conf.txmode.offloads & RTE_ETH_TX_OFFLOAD_IPV4_CKSUM);
    assert(dev->data->dev_conf.txmode.offloads & RTE_ETH_TX_OFFLOAD_TCP_CKSUM);
    assert(dev->data->dev_conf.txmode.offloads & RTE_ETH_TX_OFFLOAD_UDP_CKSUM);

#if 0
    assert(dev->data.dev_conf.rxmode.offloads.);
    assert(dev->data.dev_conf.rxmode.offloads);
    assert(dev->data.dev_conf.rxmode.offloads);
    assert(dev->data.dev_conf.rxmode.offloads);
    assert(dev->data.dev_conf.rxmode.offloads);
    assert(dev->data.dev_conf.rxmode.offloads);
    assert(dev->data.dev_conf.rxmode.offloads);
#endif

    return 0; 
}

static int
eth_dev_start(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    assert(!gemu->started);
    gemu_enable(gemu);
    return 0;
}

static int
eth_dev_stop(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    assert(gemu->started);
    gemu_disable(gemu);
    return 0;
}

static int
eth_dev_rx_queue_setup(struct rte_eth_dev *dev, uint16_t rx_queue_id,
                    uint16_t nb_rx_desc,
                    unsigned int socket_id __rte_unused,
                    const struct rte_eth_rxconf *rx_conf __rte_unused,
                    struct rte_mempool *mb_pool)
{
    RTE_DEV_GET_GEMU(dev);

    assert(rx_queue_id == 0);
    assert(mb_pool);
    assert(nb_rx_desc);

    GEMU_GET_RX_Q(gemu, rx_queue_id);
    rx_q->rxconf = *rx_conf;
    assert(nb_rx_desc <= GEMU_MAX_BDS); 
    rx_q->rx_bd_count = nb_rx_desc;
    rx_q->rx_bd_memsize = GEM_DESC_MEM_SIZE;   // (GEMU_MAX_BDS)*sizeof(gemu_desc))

    const struct rte_memzone *rx_mz = rte_eth_dma_zone_reserve(dev, "rx_bdring", rx_queue_id,
                                      rx_q->rx_bd_memsize, GEM_DMABD_ALIGNMENT, 0);

    assert(rx_mz);
    assert(rx_mz->iova);
    assert(rx_mz->addr);

    rx_q->phys_rx_bd_mem = rx_mz->iova;
    rx_q->rx_bd_mem = rx_mz->addr; 

    gemu_init_rx_bds(gemu, rx_q);

    return 0;
}

static int
eth_dev_tx_queue_setup(struct rte_eth_dev *dev, uint16_t tx_queue_id,
                    uint16_t nb_tx_desc,
                    unsigned int socket_id __rte_unused,
                    const struct rte_eth_txconf *tx_conf)
{
    RTE_DEV_GET_GEMU(dev);

    assert(tx_queue_id < 1);
    assert(nb_tx_desc);

    GEMU_GET_TX_Q(gemu, tx_queue_id);
    tx_q->txconf = *tx_conf;
    tx_q->tx_bd_count = nb_tx_desc;
    tx_q->tx_bd_memsize = GEM_DESC_MEM_SIZE;   // (GEMU_MAX_BDS)*sizeof(gemu_desc))

    const struct rte_memzone *tx_mz = rte_eth_dma_zone_reserve(dev, "tx_bdring", tx_queue_id,
                                      tx_q->tx_bd_memsize, GEM_DMABD_ALIGNMENT, 0);

    assert(tx_mz);
    assert(tx_mz->iova);
    assert(tx_mz->addr);

    tx_q->phys_tx_bd_mem = tx_mz->iova;
    tx_q->tx_bd_mem = tx_mz->addr; 

    gemu_init_tx_bds(gemu, tx_q);

    return 0;
}

static int
eth_dev_get_dev_info(struct rte_eth_dev *dev,
         struct rte_eth_dev_info *dev_info)
{
    RTE_DEV_GET_GEMU(dev);

    memset(dev_info, 0, sizeof(*dev_info));

    dev_info->max_rx_queues = 1; 
    dev_info->max_tx_queues = 2; 
    dev_info->min_rx_bufsize = GEMU_BUF_SIZE_MIN;
    dev_info->max_rx_pktlen = GEMU_FRAME_SIZE_MAX;
    dev_info->max_mac_addrs = 1; 
    dev_info->max_mtu = dev_info->max_rx_pktlen - GEMU_ETH_OVERHEAD;
    dev_info->min_mtu = RTE_ETHER_MIN_MTU;
    dev_info->rx_queue_offload_capa = 0;
    dev_info->rx_offload_capa =
                RTE_ETH_RX_OFFLOAD_IPV4_CKSUM |
                RTE_ETH_RX_OFFLOAD_UDP_CKSUM |
                RTE_ETH_RX_OFFLOAD_TCP_CKSUM;

    dev_info->tx_queue_offload_capa = 0;
    dev_info->tx_offload_capa |=
            RTE_ETH_TX_OFFLOAD_IPV4_CKSUM |
                RTE_ETH_TX_OFFLOAD_UDP_CKSUM |
                RTE_ETH_TX_OFFLOAD_TCP_CKSUM;

    dev_info->default_rxconf = (struct rte_eth_rxconf) {
                .rx_thresh = {
                        .pthresh = GEMU_DEFAULT_RX_PTHRESH,
                        .hthresh = GEMU_DEFAULT_RX_HTHRESH,
                        .wthresh = GEMU_DEFAULT_RX_WTHRESH,
                },
                .rx_free_thresh = GEMU_DEFAULT_RX_FREE_THRESH,
        };

    dev_info->default_txconf = (struct rte_eth_txconf) {
                .tx_thresh = {
                        .pthresh = GEMU_DEFAULT_TX_PTHRESH,
                        .hthresh = GEMU_DEFAULT_TX_HTHRESH,
                        .wthresh = GEMU_DEFAULT_TX_WTHRESH,
                },
                .tx_free_thresh = GEMU_DEFAULT_TX_FREE_THRESH,
                .offloads = 0,
        };

    dev_info->rx_desc_lim = (struct rte_eth_desc_lim) {
                .nb_max = GEMU_MAX_RING_DESC,
                .nb_min = GEMU_MIN_RING_DESC,
                .nb_align = GEMU_ALIGN_RING_DESC,
        };

    dev_info->tx_desc_lim = (struct rte_eth_desc_lim) {
                .nb_max = GEMU_MAX_RING_DESC,
                .nb_min = GEMU_MIN_RING_DESC,
                .nb_align = GEMU_ALIGN_RING_DESC,
                .nb_seg_max = GEMU_TX_MAX_SEG,
                .nb_mtu_seg_max = GEMU_TX_MAX_MTU_SEG,
        };


#if 0
                RTE_ETH_RX_OFFLOAD_VLAN_STRIP |
                RTE_ETH_RX_OFFLOAD_QINQ_STRIP |
                RTE_ETH_RX_OFFLOAD_IPV4_CKSUM |
                RTE_ETH_RX_OFFLOAD_UDP_CKSUM |
                RTE_ETH_RX_OFFLOAD_TCP_CKSUM |
                RTE_ETH_RX_OFFLOAD_OUTER_IPV4_CKSUM |
                RTE_ETH_RX_OFFLOAD_KEEP_CRC |
                RTE_ETH_RX_OFFLOAD_SCATTER |
                RTE_ETH_RX_OFFLOAD_VLAN_EXTEND |
                RTE_ETH_RX_OFFLOAD_VLAN_FILTER |
                RTE_ETH_RX_OFFLOAD_RSS_HASH;
#endif


    dev_info->speed_capa = RTE_ETH_LINK_SPEED_1G; 
    dev_info->default_rxportconf.nb_queues = 1;
    dev_info->default_txportconf.nb_queues = 2;
    dev_info->default_rxportconf.ring_size = 512;
    dev_info->default_txportconf.ring_size = 512;
    dev_info->default_rxportconf.burst_size = 32;
    dev_info->default_txportconf.burst_size = 32;

    return 0;
}

static int
eth_dev_stats_get(struct rte_eth_dev *dev, struct rte_eth_stats *stats)
{
    RTE_DEV_GET_GEMU(dev);

    unsigned long rx_total = 0, tx_total = 0;

    stats->ipackets = rx_total;
    stats->opackets = tx_total;

    return 0;
}

static int
eth_dev_stats_reset(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    return 0;
}

static void
eth_dev_mac_addr_remove(struct rte_eth_dev *dev __rte_unused, uint32_t index __rte_unused)
{
}

static int
eth_dev_mac_addr_add(struct rte_eth_dev *dev, struct rte_ether_addr *mac_addr)
{
    RTE_DEV_GET_GEMU(dev);

    gemu_set_mac_addr(gemu, mac_addr->addr_bytes, 0);

    return 0;
}

static int
eth_dev_allmulticast_enable(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    return 0;
}

static int
eth_dev_allmulticast_disable(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    return 0;
}

static int
eth_dev_close(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    if (rte_eal_process_type() != RTE_PROC_PRIMARY)
        return 0;

    eth_dev_stop(dev);
    gemu_dev_shutdown(gemu);

    dev->data->mac_addrs = NULL;
    gemu_pmd->gemu = NULL;

    return 0;
}

static int
eth_dev_mtu_set(struct rte_eth_dev *dev, uint16_t mtu)
{
    RTE_DEV_GET_GEMU(dev);

    mtu = mtu;
    return 0;
}

static int
eth_dev_promiscuous_enable(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    return 0; 
}

static int
eth_dev_promiscuous_disable(struct rte_eth_dev *dev)
{
    RTE_DEV_GET_GEMU(dev);

    return 0; 
}

static const struct eth_dev_ops ops = {
        .dev_start = eth_dev_start,
        .dev_stop = eth_dev_stop,
        .dev_close = eth_dev_close,
        .dev_configure = eth_dev_configure,
        .dev_infos_get = eth_dev_get_dev_info,
        .mac_addr_set = eth_dev_mac_addr_add,
        .mac_addr_remove = eth_dev_mac_addr_remove,
        .mtu_set = eth_dev_mtu_set,
        .promiscuous_enable = eth_dev_promiscuous_enable,
        .promiscuous_disable = eth_dev_promiscuous_disable,
        .allmulticast_enable = eth_dev_allmulticast_enable,
    .    allmulticast_disable = eth_dev_allmulticast_disable,
        .rx_queue_setup = eth_dev_rx_queue_setup,
        .tx_queue_setup = eth_dev_tx_queue_setup,
        .stats_get = eth_dev_stats_get,
        .stats_reset = eth_dev_stats_reset,
};

static int
eth_dev_gemu_init(unsigned int gem_id,
          const char *name,
                  struct rte_vdev_device *vdev,
                  struct rte_eth_dev **eth_dev_p)
{
    PMD_LOG(INFO, "In %s gem_id %d", __FUNCTION__, gem_id);
    if (!gm)
    {
        gm = rte_zmalloc("gemu_main", sizeof(struct gemu_main), 0);
    assert(gm);
    gemu_main_init(gm);
        PMD_LOG(INFO, "In %s gemu_main_init done", __FUNCTION__);
    }

    gemu *gemu = &gm->gemu_dev_list[gem_id]; 
    gemu_dev_init(gemu, gem_id);

    struct rte_eth_dev *eth_dev = rte_eth_dev_allocate(name);
    assert(eth_dev);
    eth_dev->device = &vdev->device;

    struct rte_eth_gemu *gemu_pmd = rte_zmalloc(name, sizeof(struct rte_eth_gemu), 0);
    assert(gemu_pmd);
    gemu_pmd->vdev = vdev;
    gemu_pmd->eth_dev = eth_dev;
    gemu_pmd->gemu = gemu; 
    gemu->app_data = gemu_pmd;

    struct rte_eth_dev_data *data = eth_dev->data; 
    data->dev_private = gemu_pmd;
    data->rx_queues = (void **)&gemu->rx_queues; 
    data->tx_queues = (void **)&gemu->tx_queues; 
    data->nb_rx_queues = 1; 
    data->nb_tx_queues = 2; 
    data->mac_addrs = (struct rte_ether_addr *)&gemu->config.mac_addr;

    *eth_dev_p = eth_dev;

    return 0;
}

static int
get_gem_id_param(const char *key __rte_unused,
                const char *value, void *extra_args)
{
    const char *a = value;
    unsigned int gem_id;

    if (value == NULL || extra_args == NULL)
                return -EINVAL;

    gem_id = (unsigned int)strtoul(a, NULL, 0);

    // only support GEM0,1 on ZCU102
    if (gem_id != 0 && gem_id != 1)
        return -1;

    *(unsigned int *)extra_args = gem_id;
    return 0;
}

static int
rte_pmd_gemu_probe(struct rte_vdev_device *dev)
{
    const char *name, *params;
    struct rte_kvargs *kvlist = NULL;
    int ret = 0;
    struct rte_eth_dev *eth_dev = NULL;
    int gem_id=0;

    name = rte_vdev_device_name(dev);
    params = rte_vdev_device_args(dev);

    PMD_LOG(INFO, "Initializing pmd_gemu for %s", name);

    if (rte_eal_process_type() == RTE_PROC_SECONDARY) {
        PMD_LOG(ERR, "Secondary process not supported %s", name);
        PMD_LOG(ERR, "Failed to probe %s", name);
        return -1;
    }

    if (params == NULL || params[0] == '\0') {
        PMD_LOG(ERR, "Must provide gem id as param %s", name);
        PMD_LOG(ERR, "Failed to probe %s", name);
        return -1;
    } else {
        kvlist = rte_kvargs_parse(params, valid_arguments);
        if (!kvlist) {
            PMD_LOG(ERR, "Unsupported parameters specified for %s", name);
        return -1;
        }

        ret = rte_kvargs_process(kvlist, ETH_GEM_ID_PARAM,
                                &get_gem_id_param, &gem_id);
        if (ret < 0)
            goto out_free;

        eth_dev_gemu_init(gem_id, name, dev, &eth_dev);
        assert(eth_dev);

        eth_dev->dev_ops = &ops;
        eth_dev->rx_pkt_burst = eth_dev_rx_pkts;
        eth_dev->tx_pkt_burst = eth_dev_tx_pkts;

        rte_eth_dev_probing_finish(eth_dev);
    }

out_free:
    rte_kvargs_free(kvlist);
    return ret;
}

static int
rte_pmd_gemu_remove(struct rte_vdev_device *dev)
{
    const char *name = rte_vdev_device_name(dev);
    struct rte_eth_dev *eth_dev = NULL;

    PMD_LOG(INFO, "Un-Initializing pmd_gemu for %s", name);

    if (name == NULL)
        return -EINVAL;

    /* find an ethdev entry */
    eth_dev = rte_eth_dev_allocated(name);
    if (eth_dev == NULL)
        return 0; /* port already released */

    eth_dev_close(eth_dev);
    rte_eth_dev_release_port(eth_dev);
    return 0;
}

static struct rte_vdev_driver pmd_gemu_drv = {
    .probe = rte_pmd_gemu_probe,
    .remove = rte_pmd_gemu_remove,
};

RTE_PMD_REGISTER_VDEV(net_gemu, pmd_gemu_drv);
RTE_PMD_REGISTER_ALIAS(net_gemu, eth_gemu);
RTE_PMD_REGISTER_PARAM_STRING(net_gemu,
        ETH_GEM_ID_PARAM"=<int> ");
