
// Refer to 
// https://github.com/DPDK/dpdk/blob/v24.11.2/lib/ethdev/rte_ethdev.h 
/**
 * Rx offload capabilities of a device.
 */
#define RTE_ETH_RX_OFFLOAD_VLAN_STRIP       RTE_BIT64(0)
#define RTE_ETH_RX_OFFLOAD_IPV4_CKSUM       RTE_BIT64(1)
#define RTE_ETH_RX_OFFLOAD_UDP_CKSUM        RTE_BIT64(2)
#define RTE_ETH_RX_OFFLOAD_TCP_CKSUM        RTE_BIT64(3)
#define RTE_ETH_RX_OFFLOAD_TCP_LRO          RTE_BIT64(4)
#define RTE_ETH_RX_OFFLOAD_QINQ_STRIP       RTE_BIT64(5)
#define RTE_ETH_RX_OFFLOAD_OUTER_IPV4_CKSUM RTE_BIT64(6)
#define RTE_ETH_RX_OFFLOAD_MACSEC_STRIP     RTE_BIT64(7)
#define RTE_ETH_RX_OFFLOAD_VLAN_FILTER      RTE_BIT64(9)
#define RTE_ETH_RX_OFFLOAD_VLAN_EXTEND      RTE_BIT64(10)
#define RTE_ETH_RX_OFFLOAD_SCATTER          RTE_BIT64(13)
/**
 * Timestamp is set by the driver in RTE_MBUF_DYNFIELD_TIMESTAMP_NAME
 * and RTE_MBUF_DYNFLAG_RX_TIMESTAMP_NAME is set in ol_flags.
 * The mbuf field and flag are registered when the offload is configured.
 */
#define RTE_ETH_RX_OFFLOAD_TIMESTAMP        RTE_BIT64(14)
#define RTE_ETH_RX_OFFLOAD_SECURITY         RTE_BIT64(15)
#define RTE_ETH_RX_OFFLOAD_KEEP_CRC         RTE_BIT64(16)
#define RTE_ETH_RX_OFFLOAD_SCTP_CKSUM       RTE_BIT64(17)
#define RTE_ETH_RX_OFFLOAD_OUTER_UDP_CKSUM  RTE_BIT64(18)
#define RTE_ETH_RX_OFFLOAD_RSS_HASH         RTE_BIT64(19)
#define RTE_ETH_RX_OFFLOAD_BUFFER_SPLIT     RTE_BIT64(20)

#define RTE_ETH_RX_OFFLOAD_CHECKSUM (RTE_ETH_RX_OFFLOAD_IPV4_CKSUM | \
				 RTE_ETH_RX_OFFLOAD_UDP_CKSUM | \
				 RTE_ETH_RX_OFFLOAD_TCP_CKSUM)
#define RTE_ETH_RX_OFFLOAD_VLAN (RTE_ETH_RX_OFFLOAD_VLAN_STRIP | \
			     RTE_ETH_RX_OFFLOAD_VLAN_FILTER | \
			     RTE_ETH_RX_OFFLOAD_VLAN_EXTEND | \
			     RTE_ETH_RX_OFFLOAD_QINQ_STRIP)

/**
 * Tx offload capabilities of a device.
 */
#define RTE_ETH_TX_OFFLOAD_VLAN_INSERT      RTE_BIT64(0)
#define RTE_ETH_TX_OFFLOAD_IPV4_CKSUM       RTE_BIT64(1)
#define RTE_ETH_TX_OFFLOAD_UDP_CKSUM        RTE_BIT64(2)
#define RTE_ETH_TX_OFFLOAD_TCP_CKSUM        RTE_BIT64(3)
#define RTE_ETH_TX_OFFLOAD_SCTP_CKSUM       RTE_BIT64(4)
#define RTE_ETH_TX_OFFLOAD_TCP_TSO          RTE_BIT64(5)
#define RTE_ETH_TX_OFFLOAD_UDP_TSO          RTE_BIT64(6)
#define RTE_ETH_TX_OFFLOAD_OUTER_IPV4_CKSUM RTE_BIT64(7)  /**< Used for tunneling packet. */
#define RTE_ETH_TX_OFFLOAD_QINQ_INSERT      RTE_BIT64(8)
#define RTE_ETH_TX_OFFLOAD_VXLAN_TNL_TSO    RTE_BIT64(9)  /**< Used for tunneling packet. */
#define RTE_ETH_TX_OFFLOAD_GRE_TNL_TSO      RTE_BIT64(10) /**< Used for tunneling packet. */
#define RTE_ETH_TX_OFFLOAD_IPIP_TNL_TSO     RTE_BIT64(11) /**< Used for tunneling packet. */
#define RTE_ETH_TX_OFFLOAD_GENEVE_TNL_TSO   RTE_BIT64(12) /**< Used for tunneling packet. */
#define RTE_ETH_TX_OFFLOAD_MACSEC_INSERT    RTE_BIT64(13)
/**
 * Multiple threads can invoke rte_eth_tx_burst() concurrently on the same
 * Tx queue without SW lock.
 */
#define RTE_ETH_TX_OFFLOAD_MT_LOCKFREE      RTE_BIT64(14)
/** Device supports multi segment send. */
#define RTE_ETH_TX_OFFLOAD_MULTI_SEGS       RTE_BIT64(15)
/**
 * Device supports optimization for fast release of mbufs.
 * When set application must guarantee that per-queue all mbufs come from the same mempool,
 * are direct, have refcnt=1, next=NULL and nb_segs=1, as done by rte_pktmbuf_prefree_seg().
 *
 * @see rte_mbuf_raw_free_bulk()
 */
#define RTE_ETH_TX_OFFLOAD_MBUF_FAST_FREE   RTE_BIT64(16)
#define RTE_ETH_TX_OFFLOAD_SECURITY         RTE_BIT64(17)
/**
 * Device supports generic UDP tunneled packet TSO.
 * Application must set RTE_MBUF_F_TX_TUNNEL_UDP and other mbuf fields required
 * for tunnel TSO.
 */
#define RTE_ETH_TX_OFFLOAD_UDP_TNL_TSO      RTE_BIT64(18)
/**
 * Device supports generic IP tunneled packet TSO.
 * Application must set RTE_MBUF_F_TX_TUNNEL_IP and other mbuf fields required
 * for tunnel TSO.
 */
#define RTE_ETH_TX_OFFLOAD_IP_TNL_TSO       RTE_BIT64(19)
/** Device supports outer UDP checksum */
#define RTE_ETH_TX_OFFLOAD_OUTER_UDP_CKSUM  RTE_BIT64(20)
/**
 * Device sends on time read from RTE_MBUF_DYNFIELD_TIMESTAMP_NAME
 * if RTE_MBUF_DYNFLAG_TX_TIMESTAMP_NAME is set in ol_flags.
 * The mbuf field and flag are registered when the offload is configured.
 */
#define RTE_ETH_TX_OFFLOAD_SEND_ON_TIMESTAMP RTE_BIT64(21)

