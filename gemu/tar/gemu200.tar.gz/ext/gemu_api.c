#include <stdio.h>
#include <stdlib.h>
#include <stdint.h>
#include <fcntl.h>
#include <unistd.h>
#include <sys/mman.h>
  
#include "gemu.h"

int gemu_get_hw_tx_desc_size()
{
}

int gemu_get_sw_tx_desc_size()
{
}

int gemu_get_hw_rx_desc_size()
{
}

int gemu_get_sw_rx_desc_size()
{
}

int gemu_get_main_data_size()
{
}

int gemu_get_max_tx_desc_count()
{
}

int gemu_get_max_rx_desc_count()
{
}

int gemu_set_main_data(int gem_id, void *gemu_main_data, int main_data_size)
{
}

int gemu_set_rx_desc(int gem_id, void *gemu, int rx_q_id, int num_hw_rx_desc, void *hw_rx_desc, int num_sw_rx_desc, void *sw_rx_desc)
{
}

int gemu_set_tx_desc(int gem_id, void *gemu, int tx_q_id, int num_hw_tx_desc, void *hw_tx_desc, int num_sw_tx_desc, void *sw_tx_desc)
{
}

int gemu_set_rx_desc_bufs(int gem_id, void *gemu, int rx_q_id, void **bufs, int buf_count)
{
}
